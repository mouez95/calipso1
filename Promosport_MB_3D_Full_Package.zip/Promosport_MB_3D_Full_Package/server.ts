/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import { createServer as createHttpServer } from 'node:http';
import path from 'node:path';
import fs from 'node:fs/promises';
import { existsSync } from 'node:fs';
import os from 'node:os';
import { exec } from 'node:child_process';
import { promisify } from 'node:util';
import { fileURLToPath } from 'node:url';
import * as webpush from 'web-push';
import {
  INITIAL_GRILLES,
  INITIAL_WEEKLY_CONCOURS,
  archiveConcoursToGrille,
  mergeGrilleArchives,
} from './src/services/promosportData.ts';
import { evaluateConcoursRealTime, isConcoursCompletelyFinished } from './src/services/matchLiveService.ts';
import { enrichConcoursWithDirectLiveFeeds, mergeConcoursPreservingScores } from './src/services/liveFootballFeed.ts';
import {
  fetchPromosportPronosticFullScan,
  scanPromosportLiveCatalogHtml,
  fetchRapidLiveMap,
  applyRapidToLiveMatches,
  PROMOSPORT_PRONOSTIC_HOME_URL,
} from './src/services/promosportSiteParser.ts';
import type { PromosportGrille, WeeklyConcours, SiteLiveMatch, SiteLiveScanPayload } from './src/types/promosport.ts';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT) || 3000;

interface ServerSyncCache {
  activeConcours: WeeklyConcours;
  grilles: PromosportGrille[];
  syncedAt: string;
  lastAttemptMs: number;
  lastRemoteSuccessMs: number;
}

const syncCache: ServerSyncCache = {
  activeConcours: INITIAL_WEEKLY_CONCOURS,
  grilles: [...INITIAL_GRILLES],
  syncedAt: new Date().toISOString(),
  lastAttemptMs: 0,
  lastRemoteSuccessMs: 0,
};

let inFlightProbePromise: Promise<void> | null = null;

// ============================================================================
// SERVER WEB PUSH (VAPID) ENGINE — Delivers desktop notifications when closed
// ============================================================================
interface PushStoreFile {
  publicKey: string;
  privateKey: string;
  subscriptions: webpush.PushSubscription[];
}

const PUSH_STORE_PATH = path.join(os.tmpdir(), 'promosport-tunisie-push-store.json');
let pushKeys: { publicKey: string; privateKey: string } | null = null;
const pushSubscriptions = new Map<string, webpush.PushSubscription>();

async function initPushStore(): Promise<void> {
  try {
    if (process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY) {
      pushKeys = {
        publicKey: process.env.VAPID_PUBLIC_KEY,
        privateKey: process.env.VAPID_PRIVATE_KEY,
      };
    } else if (existsSync(PUSH_STORE_PATH)) {
      const raw = await fs.readFile(PUSH_STORE_PATH, 'utf-8');
      const parsed = JSON.parse(raw) as Partial<PushStoreFile>;
      if (parsed.publicKey && parsed.privateKey) {
        pushKeys = { publicKey: parsed.publicKey, privateKey: parsed.privateKey };
      }
      if (Array.isArray(parsed.subscriptions)) {
        for (const sub of parsed.subscriptions) {
          if (sub && typeof sub.endpoint === 'string') {
            pushSubscriptions.set(sub.endpoint, sub);
          }
        }
      }
    }
  } catch {
    // fallback to fresh keypair generation
  }

  if (!pushKeys) {
    pushKeys = webpush.generateVAPIDKeys();
    await persistPushStore();
  }

  try {
    webpush.setVapidDetails(
      'mailto:alerts@promosport-tunisie.local',
      pushKeys.publicKey,
      pushKeys.privateKey
    );
  } catch {
    // ignore VAPID config error
  }
}

async function persistPushStore(): Promise<void> {
  if (!pushKeys) return;
  const payload: PushStoreFile = {
    publicKey: pushKeys.publicKey,
    privateKey: pushKeys.privateKey,
    subscriptions: Array.from(pushSubscriptions.values()),
  };
  await fs.writeFile(PUSH_STORE_PATH, JSON.stringify(payload), 'utf-8').catch(() => {});
}

async function broadcastDesktopPush(payload: {
  title: string;
  body: string;
  concoursNumber?: number;
  tag?: string;
  targetTab?: 'grille' | 'tirage' | 'live' | 'apk';
}): Promise<number> {
  if (!pushKeys || pushSubscriptions.size === 0) return 0;
  const messageStr = JSON.stringify(payload);
  let sentCount = 0;
  const expiredEndpoints: string[] = [];

  await Promise.all(
    Array.from(pushSubscriptions.entries()).map(async ([endpoint, sub]) => {
      try {
        await webpush.sendNotification(sub, messageStr, { TTL: 1800 });
        sentCount += 1;
      } catch (err: unknown) {
        const statusCode = (err as { statusCode?: number })?.statusCode;
        if (statusCode === 404 || statusCode === 410) {
          expiredEndpoints.push(endpoint);
        }
      }
    })
  );

  if (expiredEndpoints.length > 0) {
    for (const ep of expiredEndpoints) {
      pushSubscriptions.delete(ep);
    }
    void persistPushStore();
  }
  return sentCount;
}

// Baseline snapshots for detecting server-side goal, new grille, and winners events
let serverPrevConcoursNumber = INITIAL_WEEKLY_CONCOURS.number;
let serverPrevActivePrize = {
  concoursNumber: INITIAL_WEEKLY_CONCOURS.number,
  value: String(INITIAL_WEEKLY_CONCOURS.cagnotteEstimate || '').trim(),
};
const serverPrevMatchSnap = new Map<number, { status: string; home: number; away: number; hasScore: boolean }>();
let serverPrevWinnersSig = '';
const serverPrevLiveCatalogScores = new Map<string, { home: number; away: number }>();

function evaluateAndDispatchConcoursPushes(concours: WeeklyConcours, grilles: PromosportGrille[]): void {
  if (pushSubscriptions.size === 0) {
    serverPrevConcoursNumber = concours.number;
    serverPrevActivePrize = {
      concoursNumber: concours.number,
      value: String(concours.cagnotteEstimate || '').trim(),
    };
    serverPrevMatchSnap.clear();
    for (const m of concours.matches) {
      const hasScore = !m.isDelayed && m.scoreHome !== undefined && m.scoreAway !== undefined;
      serverPrevMatchSnap.set(m.id, {
        status: m.status,
        home: Number(m.scoreHome || 0),
        away: Number(m.scoreAway || 0),
        hasScore,
      });
    }
    return;
  }

  const currentPrize = String(concours.cagnotteEstimate || '').trim();
  if (
    serverPrevActivePrize.concoursNumber === concours.number &&
    serverPrevActivePrize.value &&
    currentPrize &&
    currentPrize !== serverPrevActivePrize.value &&
    !/^(—|-|غير محدد|قيد التحديد الرسمي)$/i.test(currentPrize)
  ) {
    void broadcastDesktopPush({
      title: `تحديث قيمة الجائزة الكبرى — القصاصة ${concours.number}`,
      body: `القيمة الجديدة للجائزة الكبرى: ${currentPrize}`,
      concoursNumber: concours.number,
      tag: `jackpot-${concours.number}-${currentPrize.replace(/\s+/g, '-')}`,
      targetTab: 'grille',
    });
  }
  serverPrevActivePrize = { concoursNumber: concours.number, value: currentPrize };

  // 1. New Concours / Grille published
  if (concours.number > serverPrevConcoursNumber) {
    serverPrevConcoursNumber = concours.number;
    void broadcastDesktopPush({
      title: `قصاصة جديدة رقم ${concours.number}`,
      body: `الجائزة الكبرى ${concours.cagnotteEstimate} — انقر لفتح القصاصة الآن`,
      concoursNumber: concours.number,
      tag: `grille-${concours.number}`,
      targetTab: 'grille',
    });
  }

  // 2. Live Goal / Full-Time / Kickoff events in Active Concours
  const isBaselineEmpty = serverPrevMatchSnap.size === 0;
  for (const m of concours.matches) {
    const hasScore =
      !m.isDelayed &&
      m.scoreHome !== undefined &&
      m.scoreAway !== undefined &&
      /^\d+$/.test(String(m.scoreHome)) &&
      /^\d+$/.test(String(m.scoreAway));
    const curH = hasScore ? Number(m.scoreHome) : 0;
    const curA = hasScore ? Number(m.scoreAway) : 0;
    const prev = serverPrevMatchSnap.get(m.id);

    if (!isBaselineEmpty && prev && !m.isDelayed && hasScore) {
      if (
        (m.status === 'live' || (prev.status === 'live' && m.status === 'finished')) &&
        ((prev.hasScore && (curH > prev.home || curA > prev.away)) || (!prev.hasScore && (curH > 0 || curA > 0)))
      ) {
        void broadcastDesktopPush({
          title: `هدف الآن! ${m.homeTeam} ${curH} - ${curA} ${m.awayTeam}`,
          body: `القصاصة ${concours.number} • الدقيقة ${m.liveMinute || "1'"}`,
          concoursNumber: concours.number,
          tag: `goal-${concours.number}-${m.id}-${curH}-${curA}`,
          targetTab: 'live',
        });
      } else if (prev.status !== 'finished' && m.status === 'finished') {
        void broadcastDesktopPush({
          title: `نهاية المقابلة: ${m.homeTeam} ${curH} - ${curA} ${m.awayTeam}`,
          body: `القصاصة ${concours.number} • النتيجة (${m.result || '-'})`,
          concoursNumber: concours.number,
          tag: `ft-${concours.number}-${m.id}`,
          targetTab: 'live',
        });
      }
    }

    serverPrevMatchSnap.set(m.id, {
      status: m.status,
      home: curH,
      away: curA,
      hasScore,
    });
  }

  // 3. Official Winners / Financial Payouts Published
  const latestOfficial = grilles.find(
    (g) => g.number < concours.number && g.status === 'official' && g.winnersFormatted && g.winnersFormatted !== 'قيد التحديد الرسمي'
  );
  if (latestOfficial) {
    const sig = `${latestOfficial.number}:${latestOfficial.winnersCount}:${latestOfficial.prizePerWinner}`;
    if (serverPrevWinnersSig && serverPrevWinnersSig !== sig) {
      void broadcastDesktopPush({
        title: `إعلان المرابيح — قصاصة رقم ${latestOfficial.number}`,
        body: `المرابيح: ${latestOfficial.winnersFormatted} • نصيب الفائز: ${latestOfficial.prizePerWinnerFormatted}`,
        concoursNumber: latestOfficial.number,
        tag: `winners-${latestOfficial.number}`,
        targetTab: 'tirage',
      });
    }
    serverPrevWinnersSig = sig;
  }
}

function evaluateAndDispatchLiveCatalogPushes(payload: SiteLiveScanPayload): void {
  const isBaseline = serverPrevLiveCatalogScores.size === 0;
  for (const m of payload.matches) {
    if (!m.hasVerifiedScore || m.status !== 'live') continue;
    const h = Number(m.scoreHome || 0);
    const a = Number(m.scoreAway || 0);
    const prev = serverPrevLiveCatalogScores.get(m.siteMatchId);
    if (!isBaseline && pushSubscriptions.size > 0 && prev && (h > prev.home || a > prev.away)) {
      void broadcastDesktopPush({
        title: `هدف مباشر! ${m.homeTeam} ${h} - ${a} ${m.awayTeam}`,
        body: `${m.competition || 'مباشر'} • الدقيقة ${m.liveMinute || "1'"}`,
        tag: `live-goal-${m.siteMatchId}-${h}-${a}`,
        targetTab: 'live',
      });
    }
    serverPrevLiveCatalogScores.set(m.siteMatchId, { home: h, away: a });
  }
}

/**
 * Permanently scans https://www.promosport-pronostic.com/welcome/promosport
 * (plus rapid live endpoint & scoreboards) for:
 * - New active grilles (auto-download & immediate promotion without delay)
 * - Immediate rollover archiving of superseded grilles into Tirage (even before winnersCount appears)
 * - Live match scores, minutes, half-times, and official payouts/winnersCount
 */
function probeOfficialPromosportSite(): Promise<void> {
  if (inFlightProbePromise) {
    return inFlightProbePromise;
  }

  inFlightProbePromise = (async () => {
    const nowMs = Date.now();
    syncCache.lastAttemptMs = nowMs;

    try {
      const siteScan = await fetchPromosportPronosticFullScan();

      // 1. Archive & promote if a newer concours appeared on promosport-pronostic.com
      if (siteScan.activeConcours) {
        if (siteScan.activeConcours.number > syncCache.activeConcours.number) {
          const matchingResult = siteScan.grilles.find(
            (g) => g.number === syncCache.activeConcours.number
          );
          const archivedPrev = archiveConcoursToGrille(syncCache.activeConcours, matchingResult);
          syncCache.grilles = mergeGrilleArchives(syncCache.grilles, [archivedPrev]);
          syncCache.activeConcours = siteScan.activeConcours;
        } else if (siteScan.activeConcours.number === syncCache.activeConcours.number) {
          syncCache.activeConcours = mergeConcoursPreservingScores(
            syncCache.activeConcours,
            siteScan.activeConcours
          );
        }
        syncCache.lastRemoteSuccessMs = nowMs;
      }

      // 2. Merge latest official/pending Tirage grilles from site
      if (siteScan.grilles.length > 0) {
        syncCache.grilles = mergeGrilleArchives(syncCache.grilles, siteScan.grilles);
        syncCache.lastRemoteSuccessMs = nowMs;
      }

      // 3. Enrich active concours matches with real-time verified scores (no fake assumptions)
      const { concours: enriched, matchedCount } = await enrichConcoursWithDirectLiveFeeds(
        syncCache.activeConcours
      );
      syncCache.activeConcours = enriched;
      if (matchedCount > 0) {
        syncCache.lastRemoteSuccessMs = nowMs;
      }
    } catch {
      // Keep clean cached state if upstream site is temporarily unreachable
    }

    // Evaluate with strict zero-assumption evaluator
    const evaluatedConcours = evaluateConcoursRealTime(syncCache.activeConcours, nowMs, null);
    syncCache.activeConcours = evaluatedConcours;

    const archivedExtra: PromosportGrille[] = [];
    if (isConcoursCompletelyFinished(evaluatedConcours, nowMs)) {
      const existing = syncCache.grilles.find((g) => g.number === evaluatedConcours.number);
      archivedExtra.push(archiveConcoursToGrille(evaluatedConcours, existing));
    }

    syncCache.grilles = mergeGrilleArchives(INITIAL_GRILLES, [...syncCache.grilles, ...archivedExtra]);
    syncCache.syncedAt = new Date(nowMs).toISOString();
    evaluateAndDispatchConcoursPushes(syncCache.activeConcours, syncCache.grilles);
  })().finally(() => {
    inFlightProbePromise = null;
  });

  return inFlightProbePromise;
}

interface ServerLiveMatchesCache {
  baseMatches: SiteLiveMatch[];
  payload: SiteLiveScanPayload;
  lastCatalogMs: number;
  lastRapidMs: number;
}

const liveMatchesCache: ServerLiveMatchesCache = {
  baseMatches: [],
  payload: {
    matches: [],
    leagues: [],
    liveCount: 0,
    totalCount: 0,
    scannedAt: new Date().toISOString(),
    sourceUrl: PROMOSPORT_PRONOSTIC_HOME_URL,
  },
  lastCatalogMs: 0,
  lastRapidMs: 0,
};

let inFlightLiveCatalogPromise: Promise<void> | null = null;

async function refreshLiveMatchesCache(forceCatalogScan = false): Promise<SiteLiveScanPayload> {
  const nowMs = Date.now();
  const needCatalog =
    forceCatalogScan ||
    liveMatchesCache.baseMatches.length === 0 ||
    nowMs - liveMatchesCache.lastCatalogMs > 20000;

  if (needCatalog) {
    if (!inFlightLiveCatalogPromise) {
      inFlightLiveCatalogPromise = (async () => {
        try {
          const [catalog, rapid] = await Promise.all([
            scanPromosportLiveCatalogHtml(),
            fetchRapidLiveMap(),
          ]);
          if (catalog.length > 0) {
            liveMatchesCache.baseMatches = catalog;
            liveMatchesCache.lastCatalogMs = Date.now();
          }
          if (liveMatchesCache.baseMatches.length > 0) {
            liveMatchesCache.payload = applyRapidToLiveMatches(liveMatchesCache.baseMatches, rapid);
            liveMatchesCache.lastRapidMs = Date.now();
            evaluateAndDispatchLiveCatalogPushes(liveMatchesCache.payload);
          }
        } catch {
          // Keep existing cached payload on transient upstream error
        }
      })().finally(() => {
        inFlightLiveCatalogPromise = null;
      });
    }
    await Promise.race([
      inFlightLiveCatalogPromise,
      new Promise<void>((resolve) => setTimeout(resolve, 6500)),
    ]);
    return liveMatchesCache.payload;
  }

  // Moment-by-moment rapid live update (every ~2.5s)
  if (nowMs - liveMatchesCache.lastRapidMs > 2500 && liveMatchesCache.baseMatches.length > 0) {
    try {
      const rapid = await fetchRapidLiveMap();
      liveMatchesCache.payload = applyRapidToLiveMatches(liveMatchesCache.baseMatches, rapid);
      liveMatchesCache.lastRapidMs = Date.now();
      evaluateAndDispatchLiveCatalogPushes(liveMatchesCache.payload);
    } catch {
      // Preserve last valid snapshot
    }
  }

  return liveMatchesCache.payload;
}

const execAsync = promisify(exec);
let activeDistBuild: Promise<void> | null = null;

interface ExportDistFile {
  path: string;
  base64: string;
  size: number;
}

async function getLatestMtimeMs(targetPath: string): Promise<number> {
  try {
    const stat = await fs.stat(targetPath);
    let newest = stat.mtimeMs;
    if (stat.isDirectory()) {
      const entries = await fs.readdir(targetPath, { withFileTypes: true });
      for (const entry of entries) {
        if (entry.name === 'node_modules' || entry.name === 'dist' || entry.name.startsWith('.')) {
          continue;
        }
        const childNewest = await getLatestMtimeMs(path.join(targetPath, entry.name));
        if (childNewest > newest) newest = childNewest;
      }
    }
    return newest;
  } catch {
    return 0;
  }
}

async function ensureBuiltDist(forceFresh = false): Promise<string> {
  const distDir = path.resolve(__dirname, 'dist');
  const distIndex = path.join(distDir, 'index.html');

  let needsBuild = forceFresh || !existsSync(distIndex);
  if (!needsBuild) {
    const distStat = await fs.stat(distIndex).catch(() => null);
    const distMtime = distStat ? distStat.mtimeMs : 0;
    const watchedPaths = ['src', 'public', 'index.html', 'vite.config.ts', 'package.json'];
    const mtimes = await Promise.all(watchedPaths.map((p) => getLatestMtimeMs(path.resolve(__dirname, p))));
    const newestSourceMtime = Math.max(...mtimes);
    if (newestSourceMtime > distMtime) {
      needsBuild = true;
    }
  }

  if (needsBuild) {
    if (!activeDistBuild) {
      activeDistBuild = execAsync('npx vite build', {
        cwd: __dirname,
        maxBuffer: 1024 * 1024 * 10,
      })
        .then(() => undefined)
        .finally(() => {
          activeDistBuild = null;
        });
    }
    await activeDistBuild;
  }

  return distDir;
}

async function collectDistFiles(dir: string, rootDir: string, out: ExportDistFile[]): Promise<void> {
  const entries = await fs.readdir(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    const relPath = path.relative(rootDir, fullPath).replace(/\\/g, '/');

    if (relPath === 'assets/aistudio' || relPath.startsWith('assets/aistudio/')) {
      continue;
    }

    if (entry.isDirectory()) {
      await collectDistFiles(fullPath, rootDir, out);
    } else if (entry.isFile()) {
      const buf = await fs.readFile(fullPath);
      out.push({
        path: relPath,
        base64: buf.toString('base64'),
        size: buf.length,
      });
    }
  }
}

async function startServer() {
  await initPushStore();

  const app = express();
  const httpServer = createHttpServer(app);
  app.use(express.json());

  // Warm cache right on server startup so first client sync is instantaneous
  void probeOfficialPromosportSite();

  // Always-on server monitor so subscribed desktop OS clients receive goals & new grilles even when app is closed
  setInterval(() => {
    if (pushSubscriptions.size > 0) {
      void probeOfficialPromosportSite();
      void refreshLiveMatchesCache(false);
    }
  }, 25000);

  // Desktop / OS Web Push API (VAPID public key, subscribe, unsubscribe, test)
  app.get('/api/push/vapid-public-key', (_req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    res.json({
      publicKey: pushKeys?.publicKey || null,
      supported: Boolean(pushKeys?.publicKey),
    });
  });

  app.post('/api/push/subscribe', async (req, res) => {
    const sub = req.body?.subscription as webpush.PushSubscription | undefined;
    if (!sub || typeof sub.endpoint !== 'string') {
      res.status(400).json({ ok: false, error: 'Invalid subscription' });
      return;
    }
    pushSubscriptions.set(sub.endpoint, sub);
    await persistPushStore();
    res.json({ ok: true, subscribersCount: pushSubscriptions.size });
  });

  app.post('/api/push/unsubscribe', async (req, res) => {
    const endpoint = req.body?.endpoint as string | undefined;
    if (endpoint) {
      pushSubscriptions.delete(endpoint);
      await persistPushStore();
    }
    res.json({ ok: true });
  });

  app.post('/api/push/test', async (req, res) => {
    const title = String(req.body?.title || `إشعارات بروموسبور نشطة — قصاصة ${syncCache.activeConcours.number}`);
    const body = String(req.body?.body || 'ستصلك إشعارات الأهداف والقصاصات الجديدة على سطح المكتب دائماً.');
    const concoursNumber = Number(req.body?.concoursNumber || syncCache.activeConcours.number);
    const sent = await broadcastDesktopPush({
      title,
      body,
      concoursNumber,
      tag: `test-${Date.now()}`,
    });
    res.json({ ok: true, sent, subscribersCount: pushSubscriptions.size });
  });

  // Live continuous & scheduled Promosport sync endpoint (bounded wait + coalesced upstream probes)
  app.get('/api/promosport/sync', async (req, res) => {
    const force = req.query.refresh === '1';
    const ageMs = Date.now() - syncCache.lastAttemptMs;

    if (force || ageMs > 10000) {
      const probePromise = probeOfficialPromosportSite();
      // Never block client HTTP responses beyond 4s waiting on upstream third-party timeouts
      await Promise.race([
        probePromise,
        new Promise<void>((resolve) => setTimeout(resolve, 4000)),
      ]);
    } else {
      const nowMs = Date.now();
      syncCache.activeConcours = evaluateConcoursRealTime(syncCache.activeConcours, nowMs, null);
      syncCache.syncedAt = new Date(nowMs).toISOString();
    }

    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.json({
      activeConcours: syncCache.activeConcours,
      grilles: syncCache.grilles,
      syncedAt: syncCache.syncedAt,
      source: syncCache.lastRemoteSuccessMs > 0 ? 'server-live' : 'server-cache',
    });
  });

  // Real-time promosport-pronostic.com full scan + moment-by-moment live scores endpoint
  app.get('/api/promosport/live-matches', async (req, res) => {
    const forceScan = req.query.scan === '1';
    const payload = await refreshLiveMatchesCache(forceScan);
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.json(payload);
  });

  // Auto-bootstrap recorded ZIP configuration & slips on new device launch
  app.get('/api/promosport/bootstrap', async (_req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Access-Control-Allow-Origin', '*');
    const bootstrapPath = path.resolve(__dirname, 'APP_BOOTSTRAP.json');
    if (existsSync(bootstrapPath)) {
      try {
        const raw = await fs.readFile(bootstrapPath, 'utf-8');
        const parsed = JSON.parse(raw);
        res.json({ available: true, ...parsed });
        return;
      } catch {
        // Fallback below
      }
    }
    res.json({ available: false });
  });

  // Export compiled production dist/ app bundle for full-app ZIP download
  app.get('/api/export/built-bundle', async (req, res) => {
    try {
      const forceFresh = req.query.fresh === '1';
      const distDir = await ensureBuiltDist(forceFresh);
      const files: ExportDistFile[] = [];
      await collectDistFiles(distDir, distDir, files);

      res.setHeader('Cache-Control', 'no-store');
      res.json({
        builtAt: new Date().toISOString(),
        freshRebuild: forceFresh,
        fileCount: files.length,
        files,
      });
    } catch (error) {
      const msg = error instanceof Error ? error.message : 'Build bundle error';
      res.status(500).json({ error: msg, files: [] });
    }
  });

  if (process.env.NODE_ENV === 'production') {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        allowedHosts: true,
        ws: { server: httpServer },
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`Promosport Tunisie server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
