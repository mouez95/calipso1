# Facebook source access notes

- A public fetch of https://www.facebook.com/PromosportTunisie/ returned the Page and a partial post preview, but not a stable machine-readable feed or image-text extraction result. This is evidence that some public page HTML is visible, not evidence that reliable unattended polling is supported.
- Meta's Page Public Content Access documentation says the feature permits reading public posts on Pages the app does not manage for analysis/display, but requires App Review and Business Verification before live use: https://developers.facebook.com/docs/features-reference/page-public-content-access/
- Meta's Pages API documentation describes access tokens and permissions for Page content: https://developers.facebook.com/documentation/pages-api
- Meta's Page Feed reference states that apps not owning/managing a Page need Page Public Content Access; it also recommends a system-user access token to avoid rate-limit issues: https://developers.facebook.com/docs/graph-api/reference/page/feed/
- Meta's App Review page explains that apps used by people without a role on the app/business require review: https://developers.facebook.com/docs/app-review/

Implementation implication: extracted coupon/winner values in embedded Facebook images need a server-side feed reader plus OCR/image parsing. For reliable closed-app pushes, the poller and push sender must run outside the APK; APK foreground timers alone do not run after Android suspends/kills the app. Do not place Meta access tokens in the APK/client bundle.