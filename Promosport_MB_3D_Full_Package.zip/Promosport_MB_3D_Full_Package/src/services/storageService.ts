/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  NotificationSettings,
  UserBetSlip,
  AppSettings,
  WeeklyConcours,
  GoalSoundStyle,
  ClickSoundStyle,
  SiteLiveMatch,
  RetainedFinishedLiveMatch,
  LiveNotificationItem,
} from '../types/promosport';

const STORAGE_KEY = 'promosport_tunisie_settings_v1';
const SLIPS_STORAGE_KEY = 'promosport_user_slips_v1';
const APP_SETTINGS_KEY = 'promosport_app_settings_v1';
const LAST_NOTIFIED_SIG_KEY = 'promosport_last_notified_grille_sig_v1';
const NOTIFIED_WINNERS_KEY = 'promosport_notified_winners_v1';
const SW_ALERT_CACHE_NAME = 'promosport-alert-state-v1';
const SW_ALERT_STATE_URL = '/__promosport_sw_state.json';

export const DEFAULT_APP_SETTINGS: AppSettings = {
  appName: 'بروموسبور تونس - MB Football',
  packageId: 'com.promosport.tunisie.mb',
  phoneNumber: '51155580',
  concoursNumber: 936,
  columnRate: 0.150,
  baseFee: 0.250,
  enableSlipsHistory: true,
};

export function loadAppSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(APP_SETTINGS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<AppSettings>;
      const merged: AppSettings = { ...DEFAULT_APP_SETTINGS, ...parsed };
      if (!merged.concoursNumber || merged.concoursNumber < DEFAULT_APP_SETTINGS.concoursNumber) {
        merged.concoursNumber = DEFAULT_APP_SETTINGS.concoursNumber;
        saveAppSettings(merged);
      }
      return merged;
    }
  } catch (err) {
    console.warn('Could not read app settings from localStorage', err);
  }
  return DEFAULT_APP_SETTINGS;
}

export function saveAppSettings(settings: AppSettings): void {
  try {
    localStorage.setItem(APP_SETTINGS_KEY, JSON.stringify(settings));
  } catch (err) {
    console.warn('Could not save app settings to localStorage', err);
  }
}

/**
 * Loads user saved bet slips. Starts strictly empty so no virtual/dummy slips are shown.
 */
export function loadUserSlips(): UserBetSlip[] {
  try {
    const raw = localStorage.getItem(SLIPS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed;
      }
    }
  } catch (err) {
    console.warn('Could not read user slips from localStorage', err);
  }
  return [];
}

/**
 * Saves user bet slips to persistent localStorage
 */
export function saveUserSlips(slips: UserBetSlip[]): void {
  try {
    localStorage.setItem(SLIPS_STORAGE_KEY, JSON.stringify(slips));
  } catch (err) {
    console.warn('Could not save user slips to localStorage', err);
  }
}

/**
 * Adds or updates a slip, ensuring sequential numbering
 */
export function saveOrUpdateSlip(slip: UserBetSlip): UserBetSlip[] {
  const current = loadUserSlips();
  const index = current.findIndex((s) => s.id === slip.id);
  let updated: UserBetSlip[];
  if (index >= 0) {
    updated = [...current];
    updated[index] = { ...slip, updatedAt: new Date().toISOString() };
  } else {
    // Number sequentially: قصاصة رقم 1, قصاصة رقم 2...
    const slipNumber = current.length + 1;
    const namedSlip: UserBetSlip = {
      ...slip,
      name: slip.name && slip.name.trim() !== '' ? slip.name : `قصاصة مسجلة رقم ${slipNumber}`,
      createdAt: slip.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    // Keep in chronological order (appended or prepended, consistently indexed)
    updated = [...current, namedSlip];
  }
  saveUserSlips(updated);
  return updated;
}

/**
 * Deletes a slip by ID
 */
export function deleteSlip(slipId: string): UserBetSlip[] {
  const current = loadUserSlips();
  const filtered = current.filter((s) => s.id !== slipId);
  // Re-number remaining slips in strict sequential order (قصاصة مسجلة رقم 1, رقم 2, رقم 3...)
  const renumbered = filtered.map((slip, index) => ({
    ...slip,
    name: `قصاصة مسجلة رقم ${index + 1}`
  }));
  saveUserSlips(renumbered);
  return renumbered;
}

/**
 * Clears all user bet slips from persistent localStorage
 */
export function clearAllSlips(): UserBetSlip[] {
  saveUserSlips([]);
  return [];
}


export const DEFAULT_SETTINGS: NotificationSettings = {
  notifyNewGrille: true,
  notifyOfficialResults: true,
  notifyJackpotRollover: true,
  notifyClosingCountdown: true,
  soundEnabled: true,
  pushNotificationsEnabled: true,
  notificationSoundEnabled: true,
  notificationSoundStyle: 'golden-chime',
  notificationSoundDurationSeconds: 2,
  goalSoundEnabled: true,
  goalSoundDurationSeconds: 2,
  goalSoundStyle: 'water-droplet',
  clickSoundEnabled: true,
  clickSoundStyle: 'soft-tap',
  durationSeconds: 10,
  checkIntervalMinutes: 15,
  lastSyncTime: new Date().toLocaleTimeString('ar-TN', { hour: '2-digit', minute: '2-digit' }),
  autoUpdateActive: true,
};

export function buildConcoursAlertSignature(concours: WeeklyConcours): string {
  const matchesCount = Array.isArray(concours.matches) ? concours.matches.length : 0;
  return `${concours.number}:${concours.cagnotteEstimate || ''}:${concours.fullDateFormatted || ''}:${matchesCount}`;
}

export function loadLastNotifiedSignature(): string | null {
  try {
    return localStorage.getItem(LAST_NOTIFIED_SIG_KEY);
  } catch {
    return null;
  }
}

export function saveLastNotifiedSignature(signature: string, concoursNumber = 0): void {
  try {
    localStorage.setItem(LAST_NOTIFIED_SIG_KEY, signature);
  } catch {
    // ignore storage errors
  }

  // Mirror state to Service Worker & Cache Storage so background sync shares the exact seen signature
  try {
    if (typeof navigator !== 'undefined' && navigator.serviceWorker?.controller) {
      navigator.serviceWorker.controller.postMessage({
        type: 'SYNC_STATE',
        lastSeenSignature: signature,
        concoursNumber,
      });
    }
    if (typeof caches !== 'undefined') {
      void caches
        .open(SW_ALERT_CACHE_NAME)
        .then((cache) =>
          cache.put(
            SW_ALERT_STATE_URL,
            new Response(
              JSON.stringify({ lastSeenSignature: signature, concoursNumber, updatedAt: Date.now() }),
              { headers: { 'Content-Type': 'application/json' } }
            )
          )
        )
        .catch(() => {});
    }
  } catch {
    // ignore cache/SW messaging errors
  }
}

export function loadSettings(): NotificationSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
    }
  } catch (err) {
    console.warn('Could not read settings from localStorage', err);
  }
  return DEFAULT_SETTINGS;
}

export function saveSettings(settings: NotificationSettings): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
  } catch (err) {
    console.warn('Could not write settings to localStorage', err);
  }
}

/**
 * Download configuration and full prompt backup as JSON
 */
export function exportBackupJSON(settings: NotificationSettings, extraData?: unknown): void {
  const fullBackup = {
    appName: "بروموسبور تونس - Promosport Tunisie 3D",
    version: "1.0.0",
    exportDate: new Date().toISOString(),
    systemPromptSpecification: `[بروموسبور تونس]
واجهة ثلاثية الأبعاد تفاعلية فائقة السلاسة مستوحاة من الهوية الرياضية التونسية والبروموسبور:
1. كرة قدم ثلاثية الأبعاد في وسط الشاشة بنسبة 50% في المركز الهندسي الدقيق للشاشة بدقة فائقة 3K Ultra-HD
- دوران من اليمين الى اليسار بدون أي انقطاع وبسلاسة مطلقة وخفة تامة.
- إمكانية تكبير وتصغير الكرة و دورانها من فوق او من تحت بحرية عبر اللمس بإصبعين أو بإصبع واحد أو عجلة الفأرة.
- دمج لوحات المسابقات الثلاث الأخيرة (932، 931، 930) مباشرة في وجوه رقعات كرة القدم مع رقم القصاصة، التاريخ، القيمة المالية، عدد الفائزين ونصيب كل فائز.
2. خلفية سوداء حالكة مع نجوم حادة ومشعة وشهب خاطفة، وشعار الجامعة والبروموسبور المضيء باليمين، والشعار المذهب المشع في الأسفل.
3. منظومة تنبيهات متقدمة مخصصة مع حفظ واستيراد وتنزيل البرومبت والإعدادات JSON.
- أرقام الجوائز والفائزين معروضة من اليسار إلى اليمين LTR.`,
    settings,
    competitionsTracked: [936, 935, 934, 933],
    dataSource: "https://www.promosport-pronostic.com/welcome/promosport",
    metadata: extraData || {}
  };

  const blob = new Blob([JSON.stringify(fullBackup, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `promosport_tunisie_backup_${Date.now()}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Import configuration from JSON file
 */
export function importBackupJSON(file: File): Promise<NotificationSettings> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const parsed = JSON.parse(content);
        const importedSettings = parsed.settings || parsed;
        const merged: NotificationSettings = {
          ...DEFAULT_SETTINGS,
          ...importedSettings
        };
        saveSettings(merged);
        resolve(merged);
      } catch (err) {
        reject(new Error('ملف JSON غير صالح أو تالف'));
      }
    };
    reader.onerror = () => reject(new Error('فشلت قراءة الملف'));
    reader.readAsText(file);
  });
}

const LAST_BOOTSTRAP_ID_KEY = 'promosport_bootstrap_export_id_v1';
const REMOTE_SYNC_ORIGIN_KEY = 'promosport_remote_sync_origin_v1';
const CACHED_CONCOURS_KEY = 'promosport_cached_concours_v1';

export function getStoredRemoteSyncOrigin(): string | null {
  try {
    const val = localStorage.getItem(REMOTE_SYNC_ORIGIN_KEY);
    return val && val.startsWith('http') ? val : null;
  } catch {
    return null;
  }
}

export function loadCachedConcours(minConcoursNumber = 936): WeeklyConcours | null {
  try {
    const raw = localStorage.getItem(CACHED_CONCOURS_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as WeeklyConcours;
    if (
      parsed &&
      typeof parsed.number === 'number' &&
      parsed.number >= minConcoursNumber &&
      Array.isArray(parsed.matches) &&
      parsed.matches.length > 0
    ) {
      return parsed;
    }
  } catch {
    // ignore storage corruption
  }
  return null;
}

export function loadNotifiedWinnersMap(): Record<number, string> {
  try {
    const raw = localStorage.getItem(NOTIFIED_WINNERS_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? (parsed as Record<number, string>) : {};
  } catch {
    return {};
  }
}

export function saveNotifiedWinnersSignature(grilleNumber: number, signature: string): void {
  try {
    const current = loadNotifiedWinnersMap();
    current[grilleNumber] = signature;
    localStorage.setItem(NOTIFIED_WINNERS_KEY, JSON.stringify(current));
  } catch {
    // ignore storage errors
  }
}

export function saveCachedConcours(concours: WeeklyConcours): void {
  try {
    if (concours && typeof concours.number === 'number' && Array.isArray(concours.matches)) {
      localStorage.setItem(CACHED_CONCOURS_KEY, JSON.stringify(concours));
    }
  } catch {
    // ignore quota errors
  }
}

export interface ZipBootstrapPayload {
  available?: boolean;
  exportId: string;
  exportedAt: string;
  remoteSyncOrigin?: string;
  protectedPin: string;
  appSettings: AppSettings;
  notificationSettings: NotificationSettings;
  userSlips: UserBetSlip[];
  activeConcours: WeeklyConcours;
  lastNotifiedSignature: string | null;
  autoCommands: {
    liveScoreTickerMs: number;
    upstreamSyncMs: number;
    goalFlameDurationMs: number;
    goalAudio: GoalSoundStyle;
    clickSoundEnabled: boolean;
    clickSoundStyle: ClickSoundStyle;
    autoActivateSlipsAndSettings: boolean;
    autoOpenBrowserOnServerStart: boolean;
    autoEnableNotifications: boolean;
  };
}

export function buildZipBootstrapPayload(
  appSettings: AppSettings,
  userSlips: UserBetSlip[],
  activeConcours: WeeklyConcours,
  remoteSyncOrigin?: string
): ZipBootstrapPayload {
  const notificationSettings = loadSettings();
  return {
    available: true,
    exportId: `zip-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    exportedAt: new Date().toISOString(),
    remoteSyncOrigin,
    protectedPin: '1777',
    appSettings,
    notificationSettings,
    userSlips,
    activeConcours,
    lastNotifiedSignature: loadLastNotifiedSignature(),
    autoCommands: {
      liveScoreTickerMs: 1000,
      upstreamSyncMs: 10000,
      goalFlameDurationMs: 7000,
      goalAudio: notificationSettings.goalSoundStyle || 'water-droplet',
      clickSoundEnabled: notificationSettings.clickSoundEnabled !== false,
      clickSoundStyle: notificationSettings.clickSoundStyle || 'soft-tap',
      autoActivateSlipsAndSettings: true,
      autoOpenBrowserOnServerStart: true,
      autoEnableNotifications: notificationSettings.pushNotificationsEnabled,
    },
  };
}

/**
 * Automatically hydrates exported ZIP settings, recorded slips, remote sync origin, and notification rules
 * before React renders on a new device/browser without clobbering newer local edits.
 */
export async function hydrateFromExportedBootstrap(): Promise<boolean> {
  if (typeof window === 'undefined' || typeof localStorage === 'undefined') {
    return false;
  }

  const endpoints = ['/promosport-bootstrap.json', '/api/promosport/bootstrap'];
  for (const endpoint of endpoints) {
    try {
      const controller = new AbortController();
      const timeoutId = window.setTimeout(() => controller.abort(), 900);
      const res = await fetch(endpoint, { cache: 'no-store', signal: controller.signal });
      window.clearTimeout(timeoutId);

      const contentType = res.headers.get('content-type') || '';
      if (!res.ok || !contentType.includes('application/json')) continue;

      const payload = (await res.json()) as Partial<ZipBootstrapPayload>;
      if (!payload || payload.available === false || !payload.exportId) continue;

      if (payload.remoteSyncOrigin && payload.remoteSyncOrigin.startsWith('http')) {
        localStorage.setItem(REMOTE_SYNC_ORIGIN_KEY, payload.remoteSyncOrigin);
      }

      if (payload.activeConcours && Array.isArray(payload.activeConcours.matches)) {
        const existingCached = loadCachedConcours();
        if (!existingCached || payload.activeConcours.number >= existingCached.number) {
          saveCachedConcours(payload.activeConcours);
        }
      }

      const appliedId = localStorage.getItem(LAST_BOOTSTRAP_ID_KEY);
      if (appliedId === payload.exportId) {
        return false;
      }

      if (payload.appSettings) {
        saveAppSettings({ ...DEFAULT_APP_SETTINGS, ...payload.appSettings });
      }
      if (payload.notificationSettings) {
        saveSettings({ ...DEFAULT_SETTINGS, ...payload.notificationSettings });
      }
      if (Array.isArray(payload.userSlips) && payload.userSlips.length > 0) {
        const existingSlips = loadUserSlips();
        const existingIds = new Set(existingSlips.map((s) => s.id));
        const mergedSlips = [
          ...existingSlips,
          ...payload.userSlips.filter((s) => !existingIds.has(s.id)),
        ];
        saveUserSlips(mergedSlips);
      }
      if (payload.lastNotifiedSignature && payload.activeConcours) {
        saveLastNotifiedSignature(payload.lastNotifiedSignature, payload.activeConcours.number);
      }

      localStorage.setItem(LAST_BOOTSTRAP_ID_KEY, payload.exportId);
      return true;
    } catch {
      // Try next source gracefully
    }
  }

  return false;
}

const LIVE_FAVORITE_MATCHES_KEY = 'promosport_live_favorite_matches_v1';
const LIVE_FAVORITE_LEAGUES_KEY = 'promosport_live_favorite_leagues_v1';
const LIVE_WATCH_MATCHES_KEY = 'promosport_live_watch_matches_v1';
const LIVE_ALWAYS_ON_KEY = 'promosport_live_always_on_v1';

function loadStringArrayKey(key: string): string[] {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.filter((x): x is string => typeof x === 'string') : [];
  } catch {
    return [];
  }
}

function saveStringArrayKey(key: string, items: string[]): void {
  try {
    localStorage.setItem(key, JSON.stringify(Array.from(new Set(items))));
  } catch {
    // ignore quota errors
  }
}

export function loadLiveFavoriteMatchIds(): string[] {
  return loadStringArrayKey(LIVE_FAVORITE_MATCHES_KEY);
}

export function saveLiveFavoriteMatchIds(ids: string[]): void {
  saveStringArrayKey(LIVE_FAVORITE_MATCHES_KEY, ids);
}

export function loadLiveFavoriteLeagues(): string[] {
  return loadStringArrayKey(LIVE_FAVORITE_LEAGUES_KEY);
}

export function saveLiveFavoriteLeagues(leagues: string[]): void {
  saveStringArrayKey(LIVE_FAVORITE_LEAGUES_KEY, leagues);
}

export function loadLiveWatchMatchIds(): string[] {
  return loadStringArrayKey(LIVE_WATCH_MATCHES_KEY);
}

export function saveLiveWatchMatchIds(ids: string[]): void {
  saveStringArrayKey(LIVE_WATCH_MATCHES_KEY, ids);
}

export function loadLiveAlwaysOn(): boolean {
  try {
    const raw = localStorage.getItem(LIVE_ALWAYS_ON_KEY);
    if (raw === null) return true;
    return raw !== 'false';
  } catch {
    return true;
  }
}

export function saveLiveAlwaysOn(enabled: boolean): void {
  try {
    localStorage.setItem(LIVE_ALWAYS_ON_KEY, enabled ? 'true' : 'false');
  } catch {
    // ignore storage errors
  }
}

const LIVE_SCAN_ENABLED_KEY = 'promosport_live_scan_enabled_v1';
const LIVE_FINISHED_24H_KEY = 'promosport_live_finished_24h_v1';
const LIVE_NOTIFICATIONS_LOG_KEY = 'promosport_live_notifications_log_v1';
export const LIVE_FINISHED_TTL_MS = 24 * 60 * 60 * 1000;

export function loadLiveScanEnabled(): boolean {
  try {
    const raw = localStorage.getItem(LIVE_SCAN_ENABLED_KEY);
    if (raw === null) return true;
    return raw !== 'false';
  } catch {
    return true;
  }
}

export function saveLiveScanEnabled(enabled: boolean): void {
  try {
    localStorage.setItem(LIVE_SCAN_ENABLED_KEY, enabled ? 'true' : 'false');
  } catch {
    // ignore storage errors
  }
}

function readRetainedFinishedRecords(nowMs = Date.now()): RetainedFinishedLiveMatch[] {
  try {
    const raw = localStorage.getItem(LIVE_FINISHED_24H_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (item): item is RetainedFinishedLiveMatch =>
        Boolean(item) &&
        typeof item === 'object' &&
        Boolean(item.match) &&
        typeof item.match.siteMatchId === 'string' &&
        typeof item.expiresAtMs === 'number' &&
        item.expiresAtMs > nowMs
    );
  } catch {
    return [];
  }
}

function writeRetainedFinishedRecords(records: RetainedFinishedLiveMatch[]): void {
  try {
    localStorage.setItem(LIVE_FINISHED_24H_KEY, JSON.stringify(records));
  } catch {
    // ignore storage errors
  }
}

function isVerifiedFinishedMatch(m: SiteLiveMatch): boolean {
  return (
    m.status === 'finished' &&
    !m.isDelayed &&
    m.hasVerifiedScore &&
    m.scoreHome !== undefined &&
    m.scoreAway !== undefined &&
    /^\d+$/.test(String(m.scoreHome)) &&
    /^\d+$/.test(String(m.scoreAway))
  );
}

export function loadRetainedFinishedLiveMatches(nowMs = Date.now()): SiteLiveMatch[] {
  const valid = readRetainedFinishedRecords(nowMs);
  writeRetainedFinishedRecords(valid);
  return valid.map((r) => r.match);
}

export function mergeAndSaveRetainedFinishedLiveMatches(
  freshMatches: SiteLiveMatch[],
  nowMs = Date.now()
): SiteLiveMatch[] {
  const activeRecords = readRetainedFinishedRecords(nowMs);
  const byId = new Map<string, RetainedFinishedLiveMatch>();

  for (const rec of activeRecords) {
    byId.set(rec.match.siteMatchId, rec);
  }

  for (const m of freshMatches) {
    if (!isVerifiedFinishedMatch(m)) continue;
    const existing = byId.get(m.siteMatchId);
    const cleanedFinished: SiteLiveMatch = {
      ...m,
      status: 'finished',
      liveMinute: undefined,
    };
    const maxFromKickoff =
      m.kickoffTimestamp && m.kickoffTimestamp > 0
        ? m.kickoffTimestamp + 26 * 60 * 60 * 1000
        : nowMs + LIVE_FINISHED_TTL_MS;
    const defaultExpiresAtMs = Math.min(nowMs + LIVE_FINISHED_TTL_MS, maxFromKickoff);
    const expiresAtMs = existing ? existing.expiresAtMs : defaultExpiresAtMs;

    if (expiresAtMs > nowMs) {
      byId.set(m.siteMatchId, {
        match: cleanedFinished,
        recordedAtMs: existing ? existing.recordedAtMs : nowMs,
        expiresAtMs,
      });
    }
  }

  const nextRecords = Array.from(byId.values())
    .filter((rec) => rec.expiresAtMs > nowMs)
    .sort((a, b) => (b.match.kickoffTimestamp || b.recordedAtMs) - (a.match.kickoffTimestamp || a.recordedAtMs));

  writeRetainedFinishedRecords(nextRecords);
  return nextRecords.map((r) => r.match);
}

export function loadLiveNotificationsLog(): LiveNotificationItem[] {
  try {
    const raw = localStorage.getItem(LIVE_NOTIFICATIONS_LOG_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (item): item is LiveNotificationItem =>
        Boolean(item) && typeof item === 'object' && typeof item.id === 'string' && typeof item.title === 'string'
    );
  } catch {
    return [];
  }
}

export function saveLiveNotificationsLog(items: LiveNotificationItem[]): void {
  try {
    localStorage.setItem(LIVE_NOTIFICATIONS_LOG_KEY, JSON.stringify(items.slice(0, 60)));
  } catch {
    // ignore storage errors
  }
}

export function clearLiveNotificationsLog(): void {
  try {
    localStorage.removeItem(LIVE_NOTIFICATIONS_LOG_KEY);
  } catch {
    // ignore storage errors
  }
}


