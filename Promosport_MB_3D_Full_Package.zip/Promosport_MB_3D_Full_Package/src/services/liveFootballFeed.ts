/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { WeeklyConcours, WeeklyConcoursMatch } from '../types/promosport';
import { computeResultSign, parseMatchScore } from './matchLiveService';
import { enrichConcoursWithPromosportSiteLive } from './promosportSiteParser';

const BASE_ESPN_SCOREBOARD_URLS = [
  'https://site.api.espn.com/apis/site/v2/sports/soccer/all/scoreboard',
  'https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.nations/scoreboard',
  'https://site.api.espn.com/apis/site/v2/sports/soccer/caf.nations/scoreboard',
  'https://site.api.espn.com/apis/site/v2/sports/soccer/esp.2/scoreboard',
  'https://site.api.espn.com/apis/site/v2/sports/soccer/esp.1/scoreboard',
  'https://site.api.espn.com/apis/site/v2/sports/soccer/eng.1/scoreboard',
  'https://site.api.espn.com/apis/site/v2/sports/soccer/ita.1/scoreboard',
  'https://site.api.espn.com/apis/site/v2/sports/soccer/fra.1/scoreboard',
  'https://site.api.espn.com/apis/site/v2/sports/soccer/ger.1/scoreboard',
];

const TEAM_ALIAS_GROUPS: string[][] = [
  ['portugal', 'البرتغال'],
  ['danemark', 'denmark', 'الدنمارك'],
  ['norvege', 'norway', 'النرويج'],
  ['paysdegalles', 'wales', 'ويلز'],
  ['irlandedunord', 'northernireland', 'nireland', 'أيرلندا الشمالية'],
  ['ukraine', 'أوكرانيا'],
  ['autriche', 'austria', 'النمسا'],
  ['irlande', 'ireland', 'repofireland', 'republicofireland', 'جمهورية أيرلندا', 'أيرلندا'],
  ['kosovo', 'كوسوفو'],
  ['roumanie', 'romania', 'رومانيا'],
  ['pologne', 'poland', 'بولندا'],
  ['suede', 'sweden', 'السويد'],
  ['bosnieherzegovine', 'bosniaandherzegovina', 'bosniaherzegovina', 'bosnia', 'البوسنة والهرسك'],
  ['georgie', 'georgia', 'جورجيا'],
  ['hongrie', 'hungary', 'المجر'],
  ['congo', 'congo-brazzaville', 'repofcongo', 'الكونغو'],
  ['comoros', 'comores', 'جزر القمر'],
  ['mauritania', 'mauritanie', 'موريتانيا'],
  ['burkinafaso', 'بوركينا فاسو'],
  ['rwanda', 'رواندا'],
  ['mali', 'مالي'],
  ['botswana', 'بوتسوانا'],
  ['ouganda', 'uganda', 'أوغندا'],
  ['liberia', 'ليبيريا'],
  ['capeverdeislands', 'capeverde', 'caboverde', 'capvert', 'الرأس الأخضر'],
  ['niger', 'النيجر'],
  ['maroc', 'morocco', 'المغرب'],
  ['algerie', 'algeria', 'الجزائر'],
  ['togo', 'توغو'],
  ['realoviedo', 'oviedo', 'ريال أوفييدو'],
  ['girona', 'gironafc', 'جيرونا'],
  ['mallorca', 'rcdmallorca', 'مايوركا'],
  ['cordoba', 'cordobacf', 'قرطبة'],
  ['realsociedadb', 'realsociedadii', 'realsociedad2', 'ريال سوسيداد ب'],
  ['sportinggijon', 'sportingdegijon', 'gijon', 'سبورتينغ خيخون'],
  ['almeria', 'udalmeria', 'ألميريا'],
  ['fcandorra', 'andorra', 'أندورا'],
  ['italie', 'italy', 'إيطاليا'],
  ['france', 'فرنسا'],
  ['turquie', 'turkey', 'turkiye', 'تركيا'],
  ['belgique', 'belgium', 'بلجيكا'],
  ['tcheque', 'czechia', 'czechrepublic', 'التشيك'],
  ['espagne', 'spain', 'إسبانيا'],
  ['angleterre', 'england', 'إنجلترا'],
  ['croatie', 'croatia', 'كرواتيا'],
  ['albanie', 'albania', 'ألبانيا'],
  ['finlande', 'finland', 'فنلندا'],
  ['montenegro', 'الجبل الأسود'],
  ['lettonie', 'latvia', 'لاتفيا'],
  ['armenie', 'armenia', 'أرمينيا'],
  ['chypre', 'cyprus', 'قبرص'],
  ['belarus', 'bielorussie', 'بيلاروسيا'],
  ['granadacf', 'granada', 'غرناطة'],
  ['laspalmas', 'udlaspalmas', 'لاس بالماس'],
  ['eibar', 'sdeibar', 'إيبار'],
  ['cadiz', 'cadizcf', 'قادش'],
  ['eldense', 'cdeldense', 'إلدينسي'],
  ['sabadell', 'cesabadell', 'ساباديل'],
  ['tenerife', 'cdtenerife', 'تينيريفي'],
  ['ceuta', 'adceutafc', 'سبتة'],
  ['guineeequatoriale', 'equatorialguinea', 'غينيا الاستوائية'],
  ['zimbabwe', 'زيمبابوي'],
  ['madagascar', 'مدغشقر'],
  ['guineebissau', 'guineabissau', 'غينيا بيساو'],
  ['cotedivoire', 'ivorycoast', 'كوت ديفوار'],
  ['gambie', 'gambia', 'غامبيا'],
  ['rdcongo', 'drcongo', 'congord', 'الكونغو الديمقراطية'],
  ['sierraleone', 'سيراليون'],
  ['benin', 'بنين'],
  ['afriquecentrale', 'centralafricanrepublic', 'إفريقيا الوسطى'],
  ['senegal', 'السنغال'],
  ['soudan', 'sudan', 'السودان'],
  ['allemagne', 'germany', 'ألمانيا'],
  ['paysbas', 'netherlands', 'holland', 'هولندا'],
  ['suisse', 'switzerland', 'سويسرا'],
  ['ecosse', 'scotland', 'إسكتلندا'],
  ['grece', 'greece', 'اليونان'],
  ['tunisie', 'tunisia', 'تونس'],
  ['egypte', 'egypt', 'مصر'],
  ['cameroun', 'cameroon', 'الكاميرون'],
  ['nigeria', 'نيجيريا'],
];

export function normalizeTeamToken(name: string): string {
  return String(name || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/rep\.?\s*of\s*/g, '')
    .replace(/republic\s+of\s+/g, '')
    .replace(/[^a-z0-9\u0600-\u06ff]/g, '');
}

const ALIAS_LOOKUP = new Map<string, Set<string>>();
for (const group of TEAM_ALIAS_GROUPS) {
  const normalizedGroup = group.map(normalizeTeamToken).filter(Boolean);
  const set = new Set<string>(normalizedGroup);
  for (const token of normalizedGroup) {
    ALIAS_LOOKUP.set(token, set);
  }
}

function getCandidateTokens(matchName?: string, frName?: string): string[] {
  const out = new Set<string>();
  for (const raw of [matchName, frName]) {
    if (!raw) continue;
    const tok = normalizeTeamToken(raw);
    if (!tok) continue;
    out.add(tok);
    const aliases = ALIAS_LOOKUP.get(tok);
    if (aliases) {
      aliases.forEach((a) => out.add(a));
    }
  }
  return Array.from(out);
}

function teamTokensMatch(candidates: string[], feedNames: string[]): boolean {
  const normalizedFeeds = feedNames.map(normalizeTeamToken).filter(Boolean);
  for (const cand of candidates) {
    if (!cand) continue;
    for (const feed of normalizedFeeds) {
      if (feed === cand) return true;
      if (cand.length >= 4 && feed.length >= 4 && (feed.includes(cand) || cand.includes(feed))) {
        if (
          (cand === 'ireland' || cand === 'irlande' || cand === 'repofireland') &&
          feed.includes('northern')
        ) {
          continue;
        }
        if (cand === 'niger' && feed.includes('nigeria')) {
          continue;
        }
        if (cand === 'congo' && (feed.includes('drcongo') || feed.includes('democrat'))) {
          continue;
        }
        return true;
      }
    }
  }
  return false;
}

interface EspnScoreboardEvent {
  date?: string;
  competitions?: Array<{
    date?: string;
    competitors?: Array<{
      homeAway?: 'home' | 'away';
      score?: string;
      team?: { displayName?: string; shortDisplayName?: string; name?: string };
    }>;
    status?: {
      displayClock?: string;
      type?: { name?: string; state?: 'pre' | 'in' | 'post'; completed?: boolean };
    };
  }>;
}

async function fetchEventsFromUrl(url: string): Promise<EspnScoreboardEvent[]> {
  try {
    const controller = new AbortController();
    const tid = setTimeout(() => controller.abort(), 4500);
    const res = await fetch(url, {
      signal: controller.signal,
      cache: 'no-store',
      headers: { Accept: 'application/json' },
    });
    clearTimeout(tid);
    if (!res.ok) return [];
    const data = (await res.json()) as { events?: EspnScoreboardEvent[] };
    return Array.isArray(data.events) ? data.events : [];
  } catch {
    return [];
  }
}

function buildEspnUrlsForConcours(concours: WeeklyConcours): string[] {
  const urls = new Set<string>(BASE_ESPN_SCOREBOARD_URLS);
  const dp = concours.dateStr.match(/(\d{2})-(\d{2})-(\d{4})/);
  if (dp) {
    const ymd = `${dp[3]}${dp[2]}${dp[1]}`;
    urls.add(`https://site.api.espn.com/apis/site/v2/sports/soccer/all/scoreboard?dates=${ymd}`);
    urls.add(`https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.nations/scoreboard?dates=${ymd}`);
    urls.add(`https://site.api.espn.com/apis/site/v2/sports/soccer/caf.nations/scoreboard?dates=${ymd}`);
  }
  return Array.from(urls);
}

function isDelayedEspnStatus(statusName?: string): boolean {
  const s = String(statusName || '').toUpperCase();
  return (
    s.includes('POSTPONED') ||
    s.includes('CANCELED') ||
    s.includes('CANCELLED') ||
    s.includes('SUSPENDED') ||
    s.includes('DELAYED') ||
    s.includes('ABANDONED')
  );
}

/**
 * Fetches verified real-time match scores & minutes from:
 * 1) Authoritative Promosport site (https://www.promosport-pronostic.com getmatchid_rapid + promo_matchs + promo_result)
 * 2) Date-validated CORS-enabled public football scoreboards (for extra coverage)
 * Delayed/postponed matches suppress scores strictly without assumptions.
 */
export async function enrichConcoursWithDirectLiveFeeds(
  concours: WeeklyConcours
): Promise<{ concours: WeeklyConcours; matchedCount: number }> {
  const [siteResult, espnResults] = await Promise.all([
    enrichConcoursWithPromosportSiteLive(concours).catch(() => ({
      concours,
      matchedCount: 0,
    })),
    Promise.allSettled(buildEspnUrlsForConcours(concours).map((url) => fetchEventsFromUrl(url))),
  ]);

  const baseConcours = siteResult.concours;
  let matchedCount = siteResult.matchedCount;

  const allEvents: EspnScoreboardEvent[] = [];
  for (const r of espnResults) {
    if (r.status === 'fulfilled' && r.value.length > 0) {
      allEvents.push(...r.value);
    }
  }

  if (allEvents.length === 0) {
    return { concours: baseConcours, matchedCount };
  }

  const updatedMatches: WeeklyConcoursMatch[] = baseConcours.matches.map((match) => {
    // Respect already-confirmed postponed/delayed state OR already-confirmed site live/finished state
    if (match.isDelayed || match.status === 'live' || match.status === 'finished') {
      return match;
    }

    const homeCandidates = getCandidateTokens(match.homeTeam, match.homeTeamFr);
    const awayCandidates = getCandidateTokens(match.awayTeam, match.awayTeamFr);
    if (homeCandidates.length === 0 || awayCandidates.length === 0) return match;

    for (const ev of allEvents) {
      const comp = ev.competitions?.[0];
      if (!comp || !Array.isArray(comp.competitors) || comp.competitors.length < 2) continue;

      // Ensure event belongs to same scheduled window (±36 hours) so prior weeks cannot mismatch
      const evDateStr = comp.date || ev.date;
      if (evDateStr && match.kickoffTimestamp > 0) {
        const evMs = Date.parse(evDateStr);
        if (Number.isFinite(evMs) && Math.abs(evMs - match.kickoffTimestamp) > 36 * 60 * 60 * 1000) {
          continue;
        }
      }

      const homeComp = comp.competitors.find((c) => c.homeAway === 'home') || comp.competitors[0];
      const awayComp = comp.competitors.find((c) => c.homeAway === 'away') || comp.competitors[1];
      if (!homeComp || !awayComp) continue;

      const feedHomeCandidates = [
        homeComp.team?.displayName || '',
        homeComp.team?.shortDisplayName || '',
        homeComp.team?.name || '',
      ];
      const feedAwayCandidates = [
        awayComp.team?.displayName || '',
        awayComp.team?.shortDisplayName || '',
        awayComp.team?.name || '',
      ];

      if (
        teamTokensMatch(homeCandidates, feedHomeCandidates) &&
        teamTokensMatch(awayCandidates, feedAwayCandidates)
      ) {
        if (isDelayedEspnStatus(comp.status?.type?.name)) {
          return {
            ...match,
            isDelayed: true,
            status: 'scheduled',
            score: '- - -',
            scoreHome: undefined,
            scoreAway: undefined,
            liveMinute: undefined,
            result: null,
          };
        }

        const state = comp.status?.type?.state;
        const completed = Boolean(comp.status?.type?.completed || state === 'post');
        const rawHome = Number(homeComp.score);
        const rawAway = Number(awayComp.score);

        if ((state === 'in' || completed) && Number.isFinite(rawHome) && Number.isFinite(rawAway)) {
          matchedCount += 1;
          if (completed) {
            return {
              ...match,
              isDelayed: false,
              status: 'finished',
              scoreHome: String(rawHome),
              scoreAway: String(rawAway),
              score: `${rawHome} - ${rawAway}`,
              liveMinute: undefined,
              result: computeResultSign(rawHome, rawAway),
            };
          }

          return {
            ...match,
            isDelayed: false,
            status: 'live',
            scoreHome: String(rawHome),
            scoreAway: String(rawAway),
            score: `${rawHome} - ${rawAway}`,
            liveMinute: comp.status?.displayClock || match.liveMinute || 'LIVE',
            result: null,
          };
        }
        break;
      }
    }

    return match;
  });

  return {
    concours: {
      ...baseConcours,
      matches: updatedMatches,
    },
    matchedCount,
  };
}

/**
 * Merges incoming concours updates cleanly:
 * - Adopts higher concours number cleanly
 * - Never fabricates 0-0 when unstarted or delayed
 * - Trusts authoritative live/final feed corrections cleanly
 */
export function mergeConcoursPreservingScores(
  current: WeeklyConcours,
  incoming: WeeklyConcours
): WeeklyConcours {
  if (incoming.number !== current.number) {
    return incoming;
  }

  const currentById = new Map<number, WeeklyConcoursMatch>();
  for (const m of current.matches) {
    currentById.set(m.id, m);
  }

  return {
    ...incoming,
    matches: incoming.matches.map((inc) => {
      const cur = currentById.get(inc.id);
      if (!cur) return inc;

      // Delayed / postponed state clears any invalid/stale scores
      if (inc.isDelayed) {
        return {
          ...cur,
          ...inc,
          status: 'scheduled',
          score: '- - -',
          scoreHome: undefined,
          scoreAway: undefined,
          liveMinute: undefined,
          result: null,
        };
      }

      const curScore = parseMatchScore(cur);
      const incScore = parseMatchScore(inc);

      if (inc.status === 'finished' && incScore) {
        return {
          ...cur,
          ...inc,
          status: 'finished',
          scoreHome: incScore.home,
          scoreAway: incScore.away,
          score: `${incScore.home} - ${incScore.away}`,
          liveMinute: undefined,
          result: inc.result || computeResultSign(Number(incScore.home), Number(incScore.away)),
        };
      }

      if (inc.status === 'live' && incScore) {
        return {
          ...cur,
          ...inc,
          status: 'live',
          scoreHome: incScore.home,
          scoreAway: incScore.away,
          score: `${incScore.home} - ${incScore.away}`,
          liveMinute: inc.liveMinute || cur.liveMinute || 'LIVE',
          result: null,
        };
      }

      // If incoming isn't live/finished yet, keep existing confirmed finished/live if incoming has no data
      if (cur.status === 'finished' && curScore) {
        return {
          ...inc,
          status: 'finished',
          scoreHome: curScore.home,
          scoreAway: curScore.away,
          score: `${curScore.home} - ${curScore.away}`,
          liveMinute: undefined,
          result: cur.result || computeResultSign(Number(curScore.home), Number(curScore.away)),
        };
      }

      if (cur.status === 'live' && curScore) {
        return {
          ...inc,
          status: 'live',
          scoreHome: curScore.home,
          scoreAway: curScore.away,
          score: `${curScore.home} - ${curScore.away}`,
          liveMinute: cur.liveMinute,
          result: null,
        };
      }

      return {
        ...cur,
        ...inc,
        status: 'scheduled',
        score: '- - -',
        scoreHome: undefined,
        scoreAway: undefined,
        liveMinute: undefined,
        result: null,
      };
    }),
  };
}
