/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

interface MbLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  showLaser?: boolean;
  showArrows?: boolean;
  showPlaque?: boolean;
}

export const MbLogo: React.FC<MbLogoProps> = ({
  size = 'md',
  className = '',
  showLaser = true,
  showArrows = true,
  showPlaque = false,
}) => {
  const dim =
    size === 'sm'
      ? 'w-10 h-10'
      : size === 'xl'
      ? 'w-40 h-44 sm:w-44 sm:h-48'
      : size === 'lg'
      ? 'w-20 h-20'
      : 'w-14 h-14';

  const shieldDim = showPlaque ? 'w-[82%] h-[84%]' : 'w-[84%] h-[84%]';

  return (
    <div className={`relative flex items-center justify-center shrink-0 ${dim} ${className}`}>
      {/* Flowing golden radial aura (soft warm glow surrounding the static emblem) */}
      {showLaser && (
        <>
          <div
            aria-hidden="true"
            className="absolute -inset-3 rounded-full pointer-events-none"
            style={{
              background:
                'radial-gradient(circle, rgba(250, 204, 21, 0.36) 0%, rgba(217, 119, 6, 0.16) 52%, transparent 74%)',
            }}
          />
          <div
            aria-hidden="true"
            className="absolute -inset-2 rounded-full pointer-events-none animate-spin"
            style={{
              animationDuration: '8s',
              animationTimingFunction: 'linear',
              background:
                'conic-gradient(from 0deg, transparent 0deg, rgba(254, 240, 138, 0.85) 32deg, rgba(245, 158, 11, 0.22) 64deg, transparent 96deg, transparent 150deg, rgba(254, 240, 138, 0.82) 185deg, rgba(245, 158, 11, 0.2) 220deg, transparent 255deg, transparent 295deg, rgba(254, 240, 138, 0.78) 325deg, transparent 355deg)',
              maskImage: 'radial-gradient(circle, transparent 42%, black 58%, transparent 95%)',
              WebkitMaskImage: 'radial-gradient(circle, transparent 42%, black 58%, transparent 95%)',
            }}
          />
        </>
      )}

      {/* Smoothly rotating orbital golden light rings encircling the stationary emblem */}
      {showArrows && (
        <div
          aria-hidden="true"
          className={`absolute pointer-events-none animate-spin ${showPlaque ? '-inset-3' : '-inset-1'}`}
          style={{ animationDuration: '5.5s', animationTimingFunction: 'linear' }}
        >
          <svg
            viewBox="0 0 140 140"
            className="w-full h-full drop-shadow-[0_0_10px_rgba(250,204,21,0.9)]"
          >
            <defs>
              <linearGradient id="mbOrbitalTrail1" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#fef9c3" stopOpacity="1" />
                <stop offset="50%" stopColor="#facc15" stopOpacity="0.88" />
                <stop offset="100%" stopColor="#d97706" stopOpacity="0.08" />
              </linearGradient>
              <linearGradient id="mbOrbitalTrail2" x1="100%" y1="100%" x2="0%" y2="0%">
                <stop offset="0%" stopColor="#fef9c3" stopOpacity="1" />
                <stop offset="50%" stopColor="#f59e0b" stopOpacity="0.85" />
                <stop offset="100%" stopColor="#b45309" stopOpacity="0.08" />
              </linearGradient>
            </defs>

            <ellipse
              cx="70"
              cy="70"
              rx="63"
              ry="47"
              transform="rotate(-24 70 70)"
              fill="none"
              stroke="url(#mbOrbitalTrail1)"
              strokeWidth="2.8"
              strokeLinecap="round"
            />
            <ellipse
              cx="70"
              cy="70"
              rx="61"
              ry="44"
              transform="rotate(28 70 70)"
              fill="none"
              stroke="url(#mbOrbitalTrail2)"
              strokeWidth="2.5"
              strokeLinecap="round"
            />
            <circle
              cx="70"
              cy="70"
              r="64"
              fill="none"
              stroke="rgba(254, 240, 138, 0.28)"
              strokeWidth="1"
              strokeDasharray="10 8"
            />
            <circle cx="22" cy="36" r="2.5" fill="#fef08a" />
            <circle cx="118" cy="102" r="2.5" fill="#fde047" />
            <circle cx="114" cy="34" r="1.9" fill="#fef9c3" />
            <circle cx="26" cy="106" r="1.9" fill="#facc15" />
          </svg>
        </div>
      )}

      {/* STATIONARY Championship Ruby-Gem Shield + Static Metallic Gold Frame & "MB" (ZERO rotation, ZERO color change) */}
      <div className={`relative z-10 flex items-center justify-center ${shieldDim}`}>
        <svg
          viewBox={showPlaque ? '0 0 220 245' : '0 0 220 205'}
          className="w-full h-full drop-shadow-[0_6px_16px_rgba(0,0,0,0.9)]"
        >
          <defs>
            {/* Fixed Static Royal Metallic Gold Frame Gradient */}
            <linearGradient id="champGoldFrame" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#fef08a" />
              <stop offset="24%" stopColor="#eab308" />
              <stop offset="52%" stopColor="#fde047" />
              <stop offset="78%" stopColor="#b45309" />
              <stop offset="100%" stopColor="#78350f" />
            </linearGradient>

            <linearGradient id="champGoldInnerRim" x1="0%" y1="100%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#78350f" />
              <stop offset="45%" stopColor="#d97706" />
              <stop offset="100%" stopColor="#fef08a" />
            </linearGradient>

            {/* Fixed Static Faceted Crimson Ruby Shield Interior */}
            <linearGradient id="champRubyBase" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#dc2626" />
              <stop offset="48%" stopColor="#991b1b" />
              <stop offset="100%" stopColor="#450a0a" />
            </linearGradient>

            {/* Fixed Static Sculpted 3D Gold MB Lettering Gradient */}
            <linearGradient id="champMbFace" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#fffbeb" />
              <stop offset="28%" stopColor="#fde047" />
              <stop offset="68%" stopColor="#eab308" />
              <stop offset="100%" stopColor="#a16207" />
            </linearGradient>

            <linearGradient id="champPlaqueBg" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#090d16" />
              <stop offset="50%" stopColor="#1e1b2e" />
              <stop offset="100%" stopColor="#090d16" />
            </linearGradient>

            <clipPath id="rubyShieldClip">
              <path d="M 110 34 C 132 45 158 50 176 50 C 176 116 155 154 110 179 C 65 154 44 116 44 50 C 62 50 88 45 110 34 Z" />
            </clipPath>
          </defs>

          {/* Subtle Decorative Side Gold Scroll Filigree */}
          <path
            d="M 33 78 C 20 82 22 108 35 118 C 28 106 28 92 34 85 Z"
            fill="url(#champGoldFrame)"
            opacity="0.92"
          />
          <path
            d="M 187 78 C 200 82 198 108 185 118 C 192 106 192 92 186 85 Z"
            fill="url(#champGoldFrame)"
            opacity="0.92"
          />

          {/* Outer Pointed Royal Gold Shield Frame */}
          <path
            d="M 110 14 C 128 32 162 40 192 40 C 192 118 164 164 110 194 C 56 164 28 118 28 40 C 58 40 92 32 110 14 Z"
            fill="url(#champGoldFrame)"
            stroke="#fef08a"
            strokeWidth="2.4"
          />

          {/* Recessed Engraved Gold Bevel */}
          <path
            d="M 110 24 C 130 39 160 46 184 46 C 184 116 160 158 110 186 C 60 158 36 116 36 46 C 60 46 90 39 110 24 Z"
            fill="#451a03"
            stroke="url(#champGoldInnerRim)"
            strokeWidth="2"
          />

          {/* Multi-Faceted Crimson Ruby Crystal Shield Core */}
          <g clipPath="url(#rubyShieldClip)">
            <rect x="40" y="30" width="140" height="156" fill="url(#champRubyBase)" />
            {/* Crystal Facet Polygons */}
            <polygon points="110,34 142,68 110,92 78,68" fill="#ef4444" opacity="0.65" />
            <polygon points="110,34 78,68 44,50" fill="#fca5a5" opacity="0.45" />
            <polygon points="110,34 176,50 142,68" fill="#b91c1c" opacity="0.7" />
            <polygon points="44,50 78,68 72,118 44,104" fill="#dc2626" opacity="0.6" />
            <polygon points="176,50 176,104 148,118 142,68" fill="#7f1d1d" opacity="0.78" />
            <polygon points="78,68 110,92 110,136 72,118" fill="#f87171" opacity="0.32" />
            <polygon points="142,68 148,118 110,136 110,92" fill="#991b1b" opacity="0.72" />
            <polygon points="72,118 110,136 110,179 65,154" fill="#b91c1c" opacity="0.78" />
            <polygon points="148,118 155,154 110,179 110,136" fill="#450a0a" opacity="0.82" />
            {/* Facet Crisp Edge Lines */}
            <path
              d="M 110 34 L 110 179 M 78 68 L 142 68 L 148 118 L 110 136 L 72 118 Z M 44 50 L 78 68 M 176 50 L 142 68 M 65 154 L 72 118 M 155 154 L 148 118"
              fill="none"
              stroke="rgba(254, 202, 202, 0.28)"
              strokeWidth="1.2"
            />
          </g>

          {/* Inner Metallic Gold Border Framing the Ruby Core */}
          <path
            d="M 110 34 C 132 45 158 50 176 50 C 176 116 155 154 110 179 C 65 154 44 116 44 50 C 62 50 88 45 110 34 Z"
            fill="none"
            stroke="url(#champGoldFrame)"
            strokeWidth="3.5"
          />

          {/* 4 Crimson Ruby Gemstones on Shield Cardinal Peaks */}
          <polygon points="110,20 115,27 110,33 105,27" fill="#ef4444" stroke="#fef08a" strokeWidth="1" />
          <polygon points="39,43 45,48 40,54 34,49" fill="#dc2626" stroke="#fef08a" strokeWidth="0.9" />
          <polygon points="181,43 186,49 180,54 175,48" fill="#dc2626" stroke="#fef08a" strokeWidth="0.9" />
          <polygon points="110,180 114,186 110,192 106,186" fill="#dc2626" stroke="#fef08a" strokeWidth="0.9" />

          {/* Heavy Sculpted 3D Bevelled Gold "MB" Monogram (Fixed Color, Fixed Position) */}
          <text
            x="112"
            y="128"
            fill="#2b0904"
            fontSize="74"
            fontWeight="900"
            textAnchor="middle"
            fontFamily="Cinzel, Georgia, Times New Roman, serif"
            letterSpacing="-2"
          >
            MB
          </text>
          <text
            x="110"
            y="125"
            fill="url(#champMbFace)"
            stroke="#5c2805"
            strokeWidth="2.4"
            paintOrder="stroke"
            fontSize="74"
            fontWeight="900"
            textAnchor="middle"
            fontFamily="Cinzel, Georgia, Times New Roman, serif"
            letterSpacing="-2"
          >
            MB
          </text>

          {/* Optional "GRAND CHAMPION" Heraldic Plaque Below Shield */}
          {showPlaque && (
            <g transform="translate(0, 6)">
              <path
                d="M 44 214 L 58 200 L 162 200 L 176 214 L 162 228 L 58 228 Z"
                fill="url(#champPlaqueBg)"
                stroke="url(#champGoldFrame)"
                strokeWidth="2.8"
              />
              <path
                d="M 50 214 L 61 204 L 159 204 L 170 214 L 159 224 L 61 224 Z"
                fill="none"
                stroke="rgba(254, 240, 138, 0.55)"
                strokeWidth="1"
              />
              <polygon points="110,194 114,200 110,205 106,200" fill="#dc2626" stroke="#fef08a" strokeWidth="0.9" />
              <text
                x="110"
                y="218"
                fill="#fef08a"
                fontSize="11.5"
                fontWeight="800"
                textAnchor="middle"
                fontFamily="Cinzel, Georgia, Times New Roman, serif"
                letterSpacing="1.6"
              >
                GRAND CHAMPION
              </text>
            </g>
          )}
        </svg>
      </div>
    </div>
  );
};
