/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

interface SaveSlipFieryPortal3DProps {
  active: boolean;
}

/**
 * Generates an ornate high-DPI procedural Tunisian Promosport banknote texture
 * cleanly in Canvas2D (zero external assets, zero 404s).
 */
function createBanknoteTexture(denomination = '100', palette: 'emerald' | 'gold' | 'sapphire' = 'emerald'): THREE.CanvasTexture {
  const canvas = createBanknoteStampCanvas(denomination, palette);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

function createBanknoteStampCanvas(
  denomination = '100',
  palette: 'emerald' | 'gold' | 'sapphire' = 'emerald'
): HTMLCanvasElement {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;

  const grad = ctx.createLinearGradient(0, 0, 256, 128);
  if (palette === 'gold') {
    grad.addColorStop(0, '#92400e');
    grad.addColorStop(0.35, '#f59e0b');
    grad.addColorStop(0.55, '#fef08a');
    grad.addColorStop(0.8, '#d97706');
    grad.addColorStop(1, '#78350f');
  } else if (palette === 'sapphire') {
    grad.addColorStop(0, '#1e3a8a');
    grad.addColorStop(0.35, '#2563eb');
    grad.addColorStop(0.55, '#bae6fd');
    grad.addColorStop(0.8, '#1d4ed8');
    grad.addColorStop(1, '#172554');
  } else {
    grad.addColorStop(0, '#065f46');
    grad.addColorStop(0.35, '#10b981');
    grad.addColorStop(0.55, '#fef08a');
    grad.addColorStop(0.8, '#059669');
    grad.addColorStop(1, '#064e3b');
  }
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 256, 128);

  // Decorative concentric guilloche rings
  ctx.strokeStyle = 'rgba(254, 249, 195, 0.35)';
  ctx.lineWidth = 1.2;
  for (let r = 14; r <= 92; r += 13) {
    ctx.beginPath();
    ctx.arc(128, 64, r, 0, Math.PI * 2);
    ctx.stroke();
  }

  // Golden border
  ctx.strokeStyle = '#fde047';
  ctx.lineWidth = 4;
  ctx.strokeRect(5, 5, 246, 118);
  ctx.strokeStyle = 'rgba(0,0,0,0.45)';
  ctx.lineWidth = 1.5;
  ctx.strokeRect(10, 10, 236, 108);

  // Holographic gold foil security strip
  const foil = ctx.createLinearGradient(74, 0, 92, 128);
  foil.addColorStop(0, '#ca8a04');
  foil.addColorStop(0.5, '#fef9c3');
  foil.addColorStop(1, '#eab308');
  ctx.fillStyle = foil;
  ctx.fillRect(74, 8, 13, 112);

  // Center emblem medallion
  ctx.beginPath();
  ctx.arc(140, 64, 27, 0, Math.PI * 2);
  ctx.fillStyle = '#07152e';
  ctx.fill();
  ctx.lineWidth = 3;
  ctx.strokeStyle = '#facc15';
  ctx.stroke();

  // Denomination labels
  ctx.fillStyle = '#fef9c3';
  ctx.font = '900 24px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(denomination, 38, 32);
  ctx.fillText(denomination, 218, 96);

  ctx.fillStyle = '#facc15';
  ctx.font = '900 18px sans-serif';
  ctx.fillText('DT', 140, 64);

  return canvas;
}

function createGoldCoinStampCanvas(): HTMLCanvasElement {
  const canvas = document.createElement('canvas');
  canvas.width = 96;
  canvas.height = 96;
  const ctx = canvas.getContext('2d')!;

  const cx = 48;
  const cy = 48;

  // Outer golden coin rim
  const rimGrad = ctx.createRadialGradient(34, 30, 6, cx, cy, 44);
  rimGrad.addColorStop(0, '#fef9c3');
  rimGrad.addColorStop(0.45, '#facc15');
  rimGrad.addColorStop(0.85, '#d97706');
  rimGrad.addColorStop(1, '#78350f');
  ctx.beginPath();
  ctx.arc(cx, cy, 43, 0, Math.PI * 2);
  ctx.fillStyle = rimGrad;
  ctx.fill();

  // Milled edge ring
  ctx.beginPath();
  ctx.arc(cx, cy, 36, 0, Math.PI * 2);
  ctx.strokeStyle = '#fef08a';
  ctx.lineWidth = 2.5;
  ctx.stroke();

  // Inner embossed face
  const faceGrad = ctx.createLinearGradient(16, 16, 80, 80);
  faceGrad.addColorStop(0, '#eab308');
  faceGrad.addColorStop(0.5, '#fde047');
  faceGrad.addColorStop(1, '#b45309');
  ctx.beginPath();
  ctx.arc(cx, cy, 32, 0, Math.PI * 2);
  ctx.fillStyle = faceGrad;
  ctx.fill();

  // Embossed DT text
  ctx.fillStyle = '#78350f';
  ctx.font = '900 22px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('DT', cx + 1, cy + 2);
  ctx.fillStyle = '#fef9c3';
  ctx.fillText('DT', cx, cy);

  return canvas;
}

export const SaveSlipFieryPortal3D: React.FC<SaveSlipFieryPortal3DProps> = ({ active }) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const moneyCanvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!active) return;

    // =========================================================================
    // LAYER A: ULTRA-RELIABLE HIGH-DPI 2D CANVAS SCATTERED BANKNOTES & COINS
    // Runs immediately from frame 0 on ALL browsers/devices/WebViews (zero GPU failure risk)
    // =========================================================================
    const moneyCanvas = moneyCanvasRef.current;
    const ctx2d = moneyCanvas?.getContext('2d');
    const stamps = [
      createBanknoteStampCanvas('100', 'emerald'),
      createBanknoteStampCanvas('50', 'gold'),
      createBanknoteStampCanvas('20', 'sapphire'),
    ];
    const coinStamp = createGoldCoinStampCanvas();

    interface Money2DParticle {
      kind: 'note' | 'coin';
      stampIdx: number;
      x: number;
      y: number;
      vx: number;
      vy: number;
      rot: number;
      vrot: number;
      flip: number;
      vflip: number;
      size: number;
      swayPhase: number;
    }

    let dpr = Math.min(window.devicePixelRatio || 1, 2);
    let viewW = window.innerWidth;
    let viewH = window.innerHeight;

    const resize2D = () => {
      if (!moneyCanvas) return;
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      viewW = moneyCanvas.clientWidth || window.innerWidth;
      viewH = moneyCanvas.clientHeight || window.innerHeight;
      moneyCanvas.width = Math.max(1, Math.floor(viewW * dpr));
      moneyCanvas.height = Math.max(1, Math.floor(viewH * dpr));
    };
    resize2D();

    const isMobile2D = viewW <= 640;
    const total2DParticles = isMobile2D ? 72 : 105;

    const particles2D: Money2DParticle[] = Array.from({ length: total2DParticles }, (_, idx) => {
      const kind: 'note' | 'coin' = idx % 3 === 0 ? 'coin' : 'note';
      const fromCenterBurst = idx < total2DParticles * 0.65;
      const cx = viewW * 0.5;
      const cy = viewH * 0.44;
      const angle = Math.random() * Math.PI * 2;
      const burstSpeed = (isMobile2D ? 220 : 320) + Math.random() * (isMobile2D ? 420 : 580);

      return {
        kind,
        stampIdx: idx % stamps.length,
        x: fromCenterBurst
          ? cx + (Math.random() - 0.5) * 60
          : Math.random() * viewW,
        y: fromCenterBurst
          ? cy + (Math.random() - 0.5) * 60
          : -40 - Math.random() * (viewH * 0.45),
        vx: fromCenterBurst
          ? Math.cos(angle) * burstSpeed
          : (Math.random() - 0.5) * 140,
        vy: fromCenterBurst
          ? Math.sin(angle) * burstSpeed - 120
          : 150 + Math.random() * 260,
        rot: Math.random() * Math.PI * 2,
        vrot: (Math.random() - 0.5) * 6.5,
        flip: Math.random() * Math.PI * 2,
        vflip: (Math.random() - 0.5) * 8.5,
        size:
          kind === 'coin'
            ? (isMobile2D ? 24 : 30) + Math.random() * 14
            : (isMobile2D ? 56 : 74) + Math.random() * 28,
        swayPhase: Math.random() * Math.PI * 2,
      };
    });

    const startTime2D = performance.now();
    let prevTime2D = startTime2D;
    let raf2D = 0;

    const render2D = () => {
      const now = performance.now();
      const elapsed = (now - startTime2D) / 1000;
      const dt = Math.min(0.04, (now - prevTime2D) / 1000);
      prevTime2D = now;

      if (!ctx2d || !moneyCanvas || elapsed > 3.15) {
        if (ctx2d && moneyCanvas) {
          ctx2d.clearRect(0, 0, moneyCanvas.width, moneyCanvas.height);
        }
        return;
      }

      ctx2d.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx2d.clearRect(0, 0, viewW, viewH);

      const fadeIn = Math.min(1, elapsed / 0.14);
      const fadeOut = elapsed > 2.05 ? Math.max(0, 1 - (elapsed - 2.05) / 0.85) : 1;
      const alpha = fadeIn * fadeOut;

      for (let i = 0; i < particles2D.length; i++) {
        const p = particles2D[i];
        const gravity = p.kind === 'coin' ? 540 : 285;
        p.vy += gravity * dt;
        p.vx *= 1 - 0.85 * dt;
        p.x += p.vx * dt + (p.kind === 'note' ? Math.sin(elapsed * 4.5 + p.swayPhase) * 65 * dt : 0);
        p.y += p.vy * dt;
        p.rot += p.vrot * dt;
        p.flip += p.vflip * dt;

        // Keep scattered notes gently drifting in view if they exit top/sides early
        if (p.x < -90) p.x = viewW + 60;
        if (p.x > viewW + 90) p.x = -60;

        if (p.y > viewH + 100) continue;

        ctx2d.save();
        ctx2d.globalAlpha = alpha;
        ctx2d.translate(p.x, p.y);
        ctx2d.rotate(p.rot);
        const flipScale = 0.25 + 0.75 * Math.abs(Math.cos(p.flip));
        ctx2d.scale(1, flipScale);

        if (p.kind === 'coin') {
          ctx2d.drawImage(coinStamp, -p.size / 2, -p.size / 2, p.size, p.size);
        } else {
          const w = p.size;
          const h = p.size * 0.5;
          ctx2d.drawImage(stamps[p.stampIdx], -w / 2, -h / 2, w, h);
        }
        ctx2d.restore();
      }

      raf2D = requestAnimationFrame(render2D);
    };
    raf2D = requestAnimationFrame(render2D);

    // =========================================================================
    // LAYER B: OPTIONAL 3D WEBGL FIERY PORTAL + EXTRA 3D NOTES/COINS
    // =========================================================================
    const container = mountRef.current;
    let cleanup3D = () => {};

    if (container) {
      const width = container.clientWidth || window.innerWidth;
      const height = container.clientHeight || window.innerHeight;
      const isCompactMobile = width <= 640;

      let renderer: THREE.WebGLRenderer | null = null;
      try {
        renderer = new THREE.WebGLRenderer({
          antialias: !isCompactMobile,
          alpha: true,
          powerPreference: 'default',
        });
      } catch {
        renderer = null;
      }

      if (renderer) {
        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(52, width / height, 0.1, 100);
        camera.position.set(0, 0, 11.5);

        renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
        renderer.setSize(width, height);
        renderer.outputColorSpace = THREE.SRGBColorSpace;
        renderer.toneMapping = THREE.ACESFilmicToneMapping;
        renderer.toneMappingExposure = 1.2;
        renderer.setClearColor(0x000000, 0);

        renderer.domElement.style.position = 'absolute';
        renderer.domElement.style.inset = '0';
        renderer.domElement.style.width = '100%';
        renderer.domElement.style.height = '100%';
        renderer.domElement.style.display = 'block';
        container.appendChild(renderer.domElement);

        const ambientLight = new THREE.AmbientLight(0xffe6b3, 1.8);
        scene.add(ambientLight);

        const keyLight = new THREE.DirectionalLight(0xfff4d6, 2.2);
        keyLight.position.set(3, 5, 8);
        scene.add(keyLight);

        const fireLight = new THREE.PointLight(0xff8c1a, 5.5, 45);
        fireLight.position.set(0, 0, 4.5);
        scene.add(fireLight);

        const portalUniforms = {
          uTime: { value: 0 },
          uRadius: { value: 0.04 },
          uOpacity: { value: 0 },
          uAspect: { value: width / Math.max(1, height) },
        };

        const portalGeo = new THREE.PlaneGeometry(36, 36);
        const portalMat = new THREE.ShaderMaterial({
          uniforms: portalUniforms,
          transparent: true,
          depthWrite: false,
          blending: THREE.AdditiveBlending,
          vertexShader: `
            varying vec2 vUv;
            void main() {
              vUv = uv;
              gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
            }
          `,
          fragmentShader: `
            uniform float uTime;
            uniform float uRadius;
            uniform float uOpacity;
            uniform float uAspect;
            varying vec2 vUv;

            float hash(vec2 p) {
              return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
            }

            float noise(vec2 p) {
              vec2 i = floor(p);
              vec2 f = fract(p);
              vec2 u = f * f * (3.0 - 2.0 * f);
              return mix(
                mix(hash(i + vec2(0.0, 0.0)), hash(i + vec2(1.0, 0.0)), u.x),
                mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x),
                u.y
              );
            }

            float fbm(vec2 p) {
              float v = 0.0;
              float a = 0.5;
              for (int i = 0; i < 4; i++) {
                v += a * noise(p);
                p = p * 2.04 + vec2(1.7, 9.2);
                a *= 0.5;
              }
              return v;
            }

            void main() {
              vec2 p = (vUv - 0.5) * 2.4;
              float r = length(p);
              float angle = atan(p.y, p.x);

              float spinAngle = angle - uTime * 4.4 + r * 2.2;
              vec2 swirlUv = vec2(cos(spinAngle), sin(spinAngle)) * r * 2.8 - vec2(uTime * 0.9, uTime * 1.35);
              float turb = fbm(swirlUv * 2.1);

              float rimDist = abs(r - uRadius + (turb - 0.5) * 0.14);
              float ringCore = exp(-rimDist * rimDist * 130.0);
              float ringHalo = exp(-rimDist * rimDist * 18.0);

              float raySpokes = pow(0.5 + 0.5 * sin(angle * 16.0 - uTime * 6.5 + turb * 3.0), 3.0);
              float rayWash = exp(-abs(r - uRadius) * 3.2) * raySpokes * 0.85;

              float insideMask = smoothstep(uRadius + 0.08, max(0.0, uRadius - 0.15), r);
              float centerHeat = exp(-r * r * 1.4) * smoothstep(0.02, 0.35, uRadius);

              vec3 whiteHot = vec3(1.0, 0.98, 0.84);
              vec3 goldFire = vec3(1.0, 0.72, 0.12);
              vec3 crimsonFlame = vec3(0.95, 0.22, 0.03);

              vec3 color = vec3(0.0);
              color += whiteHot * ringCore * 1.6;
              color += mix(crimsonFlame, goldFire, turb) * (ringHalo * 1.35 + rayWash);
              color += mix(goldFire, whiteHot, turb) * insideMask * (0.45 + 0.5 * turb) * smoothstep(0.1, 1.5, uRadius);
              color += whiteHot * centerHeat * 0.55;

              float alpha = clamp((ringCore * 1.4 + ringHalo + rayWash + insideMask * 0.78) * uOpacity, 0.0, 1.0);
              gl_FragColor = vec4(color * uOpacity, alpha);
            }
          `,
        });

        const portalDisc = new THREE.Mesh(portalGeo, portalMat);
        portalDisc.position.set(0, 0, -0.5);
        scene.add(portalDisc);

        const torusGeo1 = new THREE.TorusGeometry(1, 0.048, 16, 72);
        const torusMat1 = new THREE.MeshStandardMaterial({
          color: 0xffd700,
          emissive: 0xff6a00,
          emissiveIntensity: 2.2,
          metalness: 0.4,
          roughness: 0.25,
          transparent: true,
          opacity: 0.95,
        });
        const torusRing1 = new THREE.Mesh(torusGeo1, torusMat1);
        scene.add(torusRing1);

        const banknoteTex = createBanknoteTexture('100', 'emerald');
        const noteCount = isCompactMobile ? 55 : 90;
        const noteGeo = new THREE.PlaneGeometry(0.96, 0.48, 3, 1);
        const noteMat = new THREE.MeshBasicMaterial({
          map: banknoteTex,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 1,
        });
        const notesMesh = new THREE.InstancedMesh(noteGeo, noteMat, noteCount);
        notesMesh.frustumCulled = false;
        scene.add(notesMesh);

        const coinCount = isCompactMobile ? 45 : 70;
        const coinGeo = new THREE.CylinderGeometry(0.18, 0.18, 0.04, 16);
        const coinMat = new THREE.MeshBasicMaterial({
          color: 0xfacc15,
          transparent: true,
          opacity: 1,
        });
        const coinsMesh = new THREE.InstancedMesh(coinGeo, coinMat, coinCount);
        coinsMesh.frustumCulled = false;
        scene.add(coinsMesh);

        interface Particle3DState {
          x: number;
          y: number;
          z: number;
          vx: number;
          vy: number;
          vz: number;
          rx: number;
          ry: number;
          rz: number;
          vrx: number;
          vry: number;
          vrz: number;
          scale: number;
        }

        const noteStates: Particle3DState[] = Array.from({ length: noteCount }, () => {
          const ang = Math.random() * Math.PI * 2;
          const speed = 2.8 + Math.random() * 6.5;
          return {
            x: (Math.random() - 0.5) * 3.2,
            y: (Math.random() - 0.5) * 4.5,
            z: (Math.random() - 0.5) * 1.2,
            vx: Math.cos(ang) * speed,
            vy: Math.sin(ang) * speed + 1.5,
            vz: 1.4 + Math.random() * 4.8,
            rx: Math.random() * Math.PI * 2,
            ry: Math.random() * Math.PI * 2,
            rz: Math.random() * Math.PI * 2,
            vrx: (Math.random() - 0.5) * 8.5,
            vry: (Math.random() - 0.5) * 8.5,
            vrz: (Math.random() - 0.5) * 7.0,
            scale: 0.72 + Math.random() * 0.55,
          };
        });

        const coinStates: Particle3DState[] = Array.from({ length: coinCount }, () => {
          const ang = Math.random() * Math.PI * 2;
          const speed = 3.2 + Math.random() * 7.2;
          return {
            x: (Math.random() - 0.5) * 2.8,
            y: (Math.random() - 0.5) * 4.2,
            z: (Math.random() - 0.5) * 1.2,
            vx: Math.cos(ang) * speed,
            vy: Math.sin(ang) * speed + 1.8,
            vz: 1.8 + Math.random() * 5.2,
            rx: Math.random() * Math.PI * 2,
            ry: Math.random() * Math.PI * 2,
            rz: Math.random() * Math.PI * 2,
            vrx: (Math.random() - 0.5) * 12,
            vry: (Math.random() - 0.5) * 12,
            vrz: (Math.random() - 0.5) * 9,
            scale: 0.75 + Math.random() * 0.55,
          };
        });

        const dummy = new THREE.Object3D();
        const start3D = performance.now();
        let prev3D = start3D;
        let frame3D = 0;
        let isDisposed = false;

        const handleResize3D = () => {
          resize2D();
          if (!container || isDisposed || !renderer) return;
          const w = container.clientWidth || window.innerWidth;
          const h = container.clientHeight || window.innerHeight;
          camera.aspect = w / Math.max(1, h);
          camera.updateProjectionMatrix();
          renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
          renderer.setSize(w, h);
          portalUniforms.uAspect.value = w / Math.max(1, h);
        };
        window.addEventListener('resize', handleResize3D);

        const tick3D = () => {
          if (isDisposed || !renderer) return;
          const now = performance.now();
          const elapsed = (now - start3D) / 1000;
          if (elapsed >= 3.15) return;

          const dt = Math.min(0.05, (now - prev3D) / 1000);
          prev3D = now;

          const openProgress = Math.max(0, Math.min(1, (elapsed - 0.03) / 1.45));
          const easedOpen = Math.pow(openProgress, 1.35);
          const radius = 0.03 + easedOpen * 1.95;

          const fadeIn = Math.min(1, elapsed / 0.16);
          const fadeOut = elapsed > 1.85 ? Math.max(0, 1 - (elapsed - 1.85) / 0.75) : 1;
          const masterOpacity = fadeIn * fadeOut;

          portalUniforms.uTime.value = elapsed;
          portalUniforms.uRadius.value = radius;
          portalUniforms.uOpacity.value = masterOpacity;

          const ringWorldRadius = 0.4 + easedOpen * 11.0;
          torusRing1.scale.setScalar(ringWorldRadius);
          torusRing1.rotation.z = elapsed * 4.2;
          torusRing1.rotation.x = Math.sin(elapsed * 2.4) * 0.55;
          torusRing1.rotation.y = Math.cos(elapsed * 2.0) * 0.45;
          torusMat1.opacity = masterOpacity * 0.95;

          fireLight.intensity = (3.5 + easedOpen * 4.5) * masterOpacity;

          const moneyFade = elapsed > 1.85 ? Math.max(0, 1 - (elapsed - 1.85) / 0.85) : 1;
          noteMat.opacity = moneyFade;
          for (let i = 0; i < noteCount; i++) {
            const p = noteStates[i];
            p.vy -= 3.8 * dt;
            p.vx *= 1 - 0.45 * dt;
            p.x += p.vx * dt + Math.sin(elapsed * 5 + i) * 0.5 * dt;
            p.y += p.vy * dt;
            p.z += p.vz * dt;
            p.rx += p.vrx * dt;
            p.ry += p.vry * dt;
            p.rz += p.vrz * dt;

            dummy.position.set(p.x, p.y, p.z);
            dummy.rotation.set(p.rx, p.ry, p.rz);
            dummy.scale.setScalar(p.scale * (0.45 + 0.55 * moneyFade));
            dummy.updateMatrix();
            notesMesh.setMatrixAt(i, dummy.matrix);
          }
          notesMesh.instanceMatrix.needsUpdate = true;

          coinMat.opacity = moneyFade;
          for (let i = 0; i < coinCount; i++) {
            const c = coinStates[i];
            c.vy -= 5.2 * dt;
            c.x += c.vx * dt;
            c.y += c.vy * dt;
            c.z += c.vz * dt;
            c.rx += c.vrx * dt;
            c.ry += c.vry * dt;
            c.rz += c.vrz * dt;

            dummy.position.set(c.x, c.y, c.z);
            dummy.rotation.set(c.rx, c.ry, c.rz);
            dummy.scale.setScalar(c.scale * (0.4 + 0.6 * moneyFade));
            dummy.updateMatrix();
            coinsMesh.setMatrixAt(i, dummy.matrix);
          }
          coinsMesh.instanceMatrix.needsUpdate = true;

          renderer.render(scene, camera);
          frame3D = requestAnimationFrame(tick3D);
        };
        frame3D = requestAnimationFrame(tick3D);

        cleanup3D = () => {
          isDisposed = true;
          window.removeEventListener('resize', handleResize3D);
          cancelAnimationFrame(frame3D);
          portalGeo.dispose();
          portalMat.dispose();
          torusGeo1.dispose();
          torusMat1.dispose();
          noteGeo.dispose();
          noteMat.dispose();
          banknoteTex.dispose();
          coinGeo.dispose();
          coinMat.dispose();
          renderer?.dispose();
          if (renderer && renderer.domElement.parentNode === container) {
            container.removeChild(renderer.domElement);
          }
        };
      }
    }

    window.addEventListener('resize', resize2D);

    return () => {
      cancelAnimationFrame(raf2D);
      window.removeEventListener('resize', resize2D);
      cleanup3D();
    };
  }, [active]);

  if (!active) return null;

  return (
    <div
      aria-hidden="true"
      className="fixed inset-0 z-[120] pointer-events-none overflow-hidden"
    >
      <div ref={mountRef} className="absolute inset-0 pointer-events-none" />
      <canvas
        ref={moneyCanvasRef}
        className="absolute inset-0 w-full h-full pointer-events-none"
      />
    </div>
  );
};
