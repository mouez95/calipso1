/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Bell,
  Clock,
  Volume2,
  VolumeX,
  Smartphone,
  Save,
  Download,
  Upload,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Trophy,
  CalendarCheck,
  FileText,
  Music2,
  MousePointerClick,
} from 'lucide-react';
import { ClickSoundStyle, GoalSoundStyle, NotificationSettings } from '../types/promosport';
import {
  audioService,
  CLICK_SOUND_OPTIONS,
  GOAL_SOUND_OPTIONS,
} from '../services/audioService';
import { exportBackupJSON, importBackupJSON } from '../services/storageService';
import { ensureDesktopPushSubscribed } from '../services/webPushClient';

interface NotificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: NotificationSettings;
  onSaveSettings: (newSettings: NotificationSettings) => void;
  onImmediateApply?: (newSettings: NotificationSettings) => void;
  onTriggerTestAlert: () => void;
}

export const NotificationModal: React.FC<NotificationModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
  onImmediateApply,
  onTriggerTestAlert,
}) => {
  const [localSettings, setLocalSettings] = useState<NotificationSettings>({ ...settings });
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [importStatus, setImportStatus] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setLocalSettings({ ...settings });
    }
  }, [isOpen, settings]);

  if (!isOpen) return null;

  const updateAndActivate = (updater: (prev: NotificationSettings) => NotificationSettings) => {
    setLocalSettings((prev) => {
      const next = updater(prev);
      audioService.setSoundEnabled(next.soundEnabled);
      audioService.setGoalSoundStyle(next.goalSoundStyle);
      audioService.setClickSoundEnabled(next.clickSoundEnabled);
      audioService.setClickSoundStyle(next.clickSoundStyle);
      if (onImmediateApply) {
        onImmediateApply(next);
      }
      return next;
    });
  };

  const handleToggle = (key: keyof NotificationSettings) => {
    audioService.playClick();
    updateAndActivate((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  const handleSelectGoalSound = (style: GoalSoundStyle) => {
    updateAndActivate((prev) => ({
      ...prev,
      soundEnabled: true,
      goalSoundEnabled: true,
      goalSoundStyle: style,
    }));
    audioService.playTimedAlert(style, localSettings.goalSoundDurationSeconds, true);
  };

  const handleSelectNotificationSound = (style: GoalSoundStyle) => {
    updateAndActivate((prev) => ({
      ...prev,
      soundEnabled: true,
      notificationSoundEnabled: true,
      notificationSoundStyle: style,
    }));
    audioService.playTimedAlert(style, localSettings.notificationSoundDurationSeconds, true);
  };

  const handleToggleClickSound = (enabled: boolean) => {
    updateAndActivate((prev) => ({
      ...prev,
      clickSoundEnabled: enabled,
    }));
    if (enabled) {
      audioService.playClick(localSettings.clickSoundStyle);
    }
  };

  const handleSelectClickStyle = (style: ClickSoundStyle) => {
    updateAndActivate((prev) => ({
      ...prev,
      soundEnabled: true,
      clickSoundEnabled: true,
      clickSoundStyle: style,
    }));
    audioService.playClick(style);
  };

  const handleSave = () => {
    audioService.playChime();
    onSaveSettings(localSettings);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 1200);
  };

  const handleExport = () => {
    audioService.playClick();
    exportBackupJSON(localSettings);
  };

  const handleImportFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const imported = await importBackupJSON(file);
      setLocalSettings(imported);
      onSaveSettings(imported);
      audioService.playChime();
      setImportStatus('تم استيراد كافة الإعدادات والبرومبت بنجاح! ✅');
      setTimeout(() => setImportStatus(null), 3000);
    } catch (err) {
      setImportStatus('خطأ: الملف المرفوع غير صالح ❌');
      setTimeout(() => setImportStatus(null), 3000);
    }
  };

  const requestPushPermission = async () => {
    if (!('Notification' in window)) {
      setImportStatus('المتصفح الحالي لا يدعم إشعارات النظام المباشرة.');
      setTimeout(() => setImportStatus(null), 3500);
      return;
    }
    try {
      const { permission, subscribed } = await ensureDesktopPushSubscribed(true);
      if (permission === 'granted') {
        audioService.playChime();
        updateAndActivate((prev) => ({ ...prev, pushNotificationsEnabled: true }));
        setImportStatus(
          subscribed
            ? 'تم تفعيل إشعارات سطح المكتب (مفتوح ومغلق) بنجاح!'
            : 'تم تفعيل إشعارات سطح المكتب والجهاز بنجاح!'
        );
      } else {
        updateAndActivate((prev) => ({ ...prev, pushNotificationsEnabled: false }));
        setImportStatus('يرجى السماح بالإشعارات من إعدادات المتصفح لتلقي تنبيهات سطح المكتب.');
      }
    } catch {
      updateAndActivate((prev) => ({ ...prev, pushNotificationsEnabled: false }));
    }
    setTimeout(() => setImportStatus(null), 3500);
  };

  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center p-4 bg-black/90 md:bg-black/85 md:backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-2xl max-h-[92vh] overflow-y-auto bg-stone-950 border border-yellow-500/50 rounded-3xl p-5 sm:p-8 shadow-[0_0_50px_rgba(234,179,8,0.25)] text-white">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-stone-800 pb-4 mb-6">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-yellow-500/10 border border-yellow-500/40 text-yellow-400 shadow-[0_0_15px_rgba(234,179,8,0.3)]">
              <Bell className="w-6 h-6 animate-bounce" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-yellow-400 to-red-500">
                منظومة التنبيهات المتقدمة
              </h2>
              <p className="text-xs text-gray-400">
                إدارة الإشعارات الفورية، التحديث التلقائي، والنسخ الاحتياطي
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              audioService.playClick();
              onClose();
            }}
            className="p-2 rounded-full bg-stone-900 hover:bg-stone-800 text-gray-400 hover:text-white border border-stone-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {importStatus && (
          <div className="mb-4 p-3 rounded-xl bg-yellow-500/20 border border-yellow-400/50 text-yellow-300 text-xs font-semibold text-center animate-pulse">
            {importStatus}
          </div>
        )}

        {/* Section 1: Specific Alert Toggles */}
        <div className="space-y-4 mb-6">
          <h3 className="text-sm font-bold text-yellow-400 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-yellow-400" />
            تخصيص وتفعيل التنبيهات المحددة
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* 1. New Grilles */}
            <div
              onClick={() => handleToggle('notifyNewGrille')}
              className={`p-3.5 rounded-2xl border transition-all duration-300 cursor-pointer flex items-center justify-between select-none ${
                localSettings.notifyNewGrille
                  ? 'bg-gradient-to-r from-yellow-500/20 to-red-600/15 border-yellow-400 shadow-[0_0_15px_rgba(234,179,8,0.3)]'
                  : 'bg-stone-900/60 border-stone-800 opacity-60 hover:opacity-90'
              }`}
            >
              <div className="flex items-center gap-3">
                <FileText
                  className={`w-5 h-5 ${
                    localSettings.notifyNewGrille ? 'text-yellow-400 animate-pulse' : 'text-gray-500'
                  }`}
                />
                <div>
                  <div className="text-xs font-bold">صدور القصاصات الجديدة</div>
                  <div className="text-[11px] text-gray-400">تنبيه فوري عند نشر مسابقة جديدة</div>
                </div>
              </div>
              <div
                className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                  localSettings.notifyNewGrille
                    ? 'border-yellow-400 bg-yellow-500 text-black'
                    : 'border-gray-600 bg-transparent'
                }`}
              >
                {localSettings.notifyNewGrille && <CheckCircle2 className="w-3.5 h-3.5" />}
              </div>
            </div>

            {/* 2. Official Results & Winners */}
            <div
              onClick={() => handleToggle('notifyOfficialResults')}
              className={`p-3.5 rounded-2xl border transition-all duration-300 cursor-pointer flex items-center justify-between select-none ${
                localSettings.notifyOfficialResults
                  ? 'bg-gradient-to-r from-yellow-500/20 to-red-600/15 border-yellow-400 shadow-[0_0_15px_rgba(234,179,8,0.3)]'
                  : 'bg-stone-900/60 border-stone-800 opacity-60 hover:opacity-90'
              }`}
            >
              <div className="flex items-center gap-3">
                <Trophy
                  className={`w-5 h-5 ${
                    localSettings.notifyOfficialResults ? 'text-yellow-400 animate-pulse' : 'text-gray-500'
                  }`}
                />
                <div>
                  <div className="text-xs font-bold">إعلان النتائج الرسمية والفائزين</div>
                  <div className="text-[11px] text-gray-400">نتائج المباريات وقيمة الأرباح</div>
                </div>
              </div>
              <div
                className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                  localSettings.notifyOfficialResults
                    ? 'border-yellow-400 bg-yellow-500 text-black'
                    : 'border-gray-600 bg-transparent'
                }`}
              >
                {localSettings.notifyOfficialResults && <CheckCircle2 className="w-3.5 h-3.5" />}
              </div>
            </div>

            {/* 3. Jackpot Rollover */}
            <div
              onClick={() => handleToggle('notifyJackpotRollover')}
              className={`p-3.5 rounded-2xl border transition-all duration-300 cursor-pointer flex items-center justify-between select-none ${
                localSettings.notifyJackpotRollover
                  ? 'bg-gradient-to-r from-yellow-500/20 to-red-600/15 border-yellow-400 shadow-[0_0_15px_rgba(234,179,8,0.3)]'
                  : 'bg-stone-900/60 border-stone-800 opacity-60 hover:opacity-90'
              }`}
            >
              <div className="flex items-center gap-3">
                <Sparkles
                  className={`w-5 h-5 ${
                    localSettings.notifyJackpotRollover ? 'text-yellow-400 animate-pulse' : 'text-gray-500'
                  }`}
                />
                <div>
                  <div className="text-xs font-bold">ترحيل الجوائز الكبرى (Cagnotte)</div>
                  <div className="text-[11px] text-gray-400">إشعار عند ترحيل مبالغ قياسية</div>
                </div>
              </div>
              <div
                className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                  localSettings.notifyJackpotRollover
                    ? 'border-yellow-400 bg-yellow-500 text-black'
                    : 'border-gray-600 bg-transparent'
                }`}
              >
                {localSettings.notifyJackpotRollover && <CheckCircle2 className="w-3.5 h-3.5" />}
              </div>
            </div>

            {/* 4. Closing countdown alerts */}
            <div
              onClick={() => handleToggle('notifyClosingCountdown')}
              className={`p-3.5 rounded-2xl border transition-all duration-300 cursor-pointer flex items-center justify-between select-none ${
                localSettings.notifyClosingCountdown
                  ? 'bg-gradient-to-r from-yellow-500/20 to-red-600/15 border-yellow-400 shadow-[0_0_15px_rgba(234,179,8,0.3)]'
                  : 'bg-stone-900/60 border-stone-800 opacity-60 hover:opacity-90'
              }`}
            >
              <div className="flex items-center gap-3">
                <CalendarCheck
                  className={`w-5 h-5 ${
                    localSettings.notifyClosingCountdown ? 'text-yellow-400 animate-pulse' : 'text-gray-500'
                  }`}
                />
                <div>
                  <div className="text-xs font-bold">تنبيهات موعد غلق المسابقة</div>
                  <div className="text-[11px] text-gray-400">تذكير قبل انتهاء أجل التحقق</div>
                </div>
              </div>
              <div
                className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                  localSettings.notifyClosingCountdown
                    ? 'border-yellow-400 bg-yellow-500 text-black'
                    : 'border-gray-600 bg-transparent'
                }`}
              >
                {localSettings.notifyClosingCountdown && <CheckCircle2 className="w-3.5 h-3.5" />}
              </div>
            </div>

            {/* 5. Sound effects */}
            <div
              onClick={() => handleToggle('soundEnabled')}
              className={`p-3.5 rounded-2xl border transition-all duration-300 cursor-pointer flex items-center justify-between select-none ${
                localSettings.soundEnabled
                  ? 'bg-gradient-to-r from-emerald-500/20 to-stone-900 border-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.3)]'
                  : 'bg-stone-900/60 border-stone-800 opacity-60 hover:opacity-90'
              }`}
            >
              <div className="flex items-center gap-3">
                {localSettings.soundEnabled ? (
                  <Volume2 className="w-5 h-5 text-emerald-400 animate-pulse" />
                ) : (
                  <VolumeX className="w-5 h-5 text-gray-500" />
                )}
                <div>
                  <div className="text-xs font-bold">النغمات الصوتية التفاعلية</div>
                  <div className="text-[11px] text-gray-400">أصوات التنبيه والنقر والموجات الذهبية</div>
                </div>
              </div>
              <div
                className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                  localSettings.soundEnabled
                    ? 'border-emerald-400 bg-emerald-500 text-black'
                    : 'border-gray-600 bg-transparent'
                }`}
              >
                {localSettings.soundEnabled && <CheckCircle2 className="w-3.5 h-3.5" />}
              </div>
            </div>

            {/* 6. Push Notifications */}
            <div
              onClick={requestPushPermission}
              className={`p-3.5 rounded-2xl border transition-all duration-300 cursor-pointer flex items-center justify-between select-none ${
                localSettings.pushNotificationsEnabled
                  ? 'bg-gradient-to-r from-cyan-500/20 to-stone-900 border-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.3)]'
                  : 'bg-stone-900/60 border-stone-800 opacity-60 hover:opacity-90'
              }`}
            >
              <div className="flex items-center gap-3">
                <Smartphone
                  className={`w-5 h-5 ${
                    localSettings.pushNotificationsEnabled ? 'text-cyan-400 animate-pulse' : 'text-gray-500'
                  }`}
                />
                <div>
                  <div className="text-xs font-bold">إشعارات سطح المكتب (مفتوح أو مغلق)</div>
                  <div className="text-[11px] text-gray-400">وصول الأهداف والقصاصات لسطح المكتب دوماً</div>
                </div>
              </div>
              <div
                className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                  localSettings.pushNotificationsEnabled
                    ? 'border-cyan-400 bg-cyan-500 text-black'
                    : 'border-gray-600 bg-transparent'
                }`}
              >
                {localSettings.pushNotificationsEnabled && <CheckCircle2 className="w-3.5 h-3.5" />}
              </div>
            </div>
          </div>
        </div>

        <div className="mb-6 p-4 rounded-2xl bg-stone-900/70 border border-cyan-500/35 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-xs font-black text-cyan-300">
              <Bell className="w-4 h-4 shrink-0" />
              <span>صوت إشعارات القصاصة والقيمة المالية والمرابيح</span>
            </div>
            <button type="button" onClick={() => handleToggle('notificationSoundEnabled')} className={`px-3 py-1.5 rounded-lg text-[11px] font-black ${localSettings.notificationSoundEnabled ? 'bg-emerald-500 text-black' : 'bg-red-600 text-white'}`}>
              {localSettings.notificationSoundEnabled ? 'مفعل' : 'صامت'}
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {GOAL_SOUND_OPTIONS.map((opt) => (
              <button key={`notification-${opt.id}`} type="button" onClick={() => handleSelectNotificationSound(opt.id)} className={`min-h-[42px] p-2.5 rounded-xl border text-right text-xs font-black transition-all ${localSettings.notificationSoundStyle === opt.id && localSettings.notificationSoundEnabled ? 'bg-cyan-500/20 border-cyan-300 text-cyan-100' : 'bg-stone-950/80 border-stone-800 text-gray-300 hover:border-cyan-500/40'}`}>
                {opt.label}
                {localSettings.notificationSoundStyle === opt.id && localSettings.notificationSoundEnabled && <CheckCircle2 className="inline w-3.5 h-3.5 mr-1 text-cyan-300" />}
              </button>
            ))}
          </div>
          <div className="flex flex-wrap items-center gap-2 text-[11px]">
            <span className="text-gray-300 font-bold">مدة صوت الإشعار:</span>
            {[1, 2, 3, 5].map((seconds) => (
              <button key={`notification-duration-${seconds}`} type="button" onClick={() => updateAndActivate((prev) => ({ ...prev, notificationSoundDurationSeconds: seconds as 1 | 2 | 3 | 5 }))} className={`px-3 py-1.5 rounded-lg border font-black ${localSettings.notificationSoundDurationSeconds === seconds ? 'bg-cyan-400 text-black border-cyan-200' : 'bg-stone-950 text-gray-300 border-stone-700'}`}>
                {seconds} ث
              </button>
            ))}
          </div>
        </div>

        {/* Goal sounds: independently enabled and duration-controlled */}
        <div className="mb-6 p-4 rounded-2xl bg-stone-900/70 border border-yellow-500/35 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-xs font-black text-yellow-400">
              <Music2 className="w-4 h-4 shrink-0" />
              <span>اختيار صوت الأهداف ومدته</span>
            </div>
            <button type="button" onClick={() => handleToggle('goalSoundEnabled')} className={`px-3 py-1.5 rounded-lg text-[11px] font-black ${localSettings.goalSoundEnabled ? 'bg-emerald-500 text-black' : 'bg-red-600 text-white'}`}>
              {localSettings.goalSoundEnabled ? 'مفعل' : 'صامت'}
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            {GOAL_SOUND_OPTIONS.map((opt) => {
              const isSelected = localSettings.goalSoundStyle === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => handleSelectGoalSound(opt.id)}
                  className={`min-h-[44px] p-3 rounded-xl border text-right transition-all duration-200 cursor-pointer flex flex-col justify-between gap-1.5 active:scale-95 ${
                    isSelected
                      ? 'bg-gradient-to-br from-yellow-400/25 via-amber-500/15 to-red-600/20 border-yellow-400 shadow-[0_0_16px_rgba(234,179,8,0.4)]'
                      : 'bg-stone-950/80 border-stone-800 hover:border-yellow-500/40'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className={`text-xs font-black ${isSelected ? 'text-yellow-300' : 'text-gray-200'}`}>
                      {opt.label}
                    </span>
                    {isSelected && <CheckCircle2 className="w-4 h-4 text-yellow-400 shrink-0" />}
                  </div>
                  <p className="text-[10.5px] text-gray-400 leading-snug">{opt.description}</p>
                  <div className="flex items-center justify-between pt-1 border-t border-white/10 text-[10.5px] font-bold">
                    <span className="text-gray-400">مدة الصوت:</span>
                    <span className="text-cyan-300 font-mono tabular-nums">{localSettings.goalSoundDurationSeconds} ث</span>
                  </div>
                </button>
              );
            })}
          </div>
          <div className="flex flex-wrap items-center gap-2 text-[11px]">
            <span className="text-gray-300 font-bold">مدة صوت الهدف:</span>
            {[1, 2, 3, 5].map((seconds) => (
              <button key={`goal-duration-${seconds}`} type="button" onClick={() => updateAndActivate((prev) => ({ ...prev, goalSoundDurationSeconds: seconds as 1 | 2 | 3 | 5 }))} className={`px-3 py-1.5 rounded-lg border font-black ${localSettings.goalSoundDurationSeconds === seconds ? 'bg-yellow-400 text-black border-yellow-200' : 'bg-stone-950 text-gray-300 border-stone-700'}`}>
                {seconds} ث
              </button>
            ))}
          </div>
        </div>

        {/* Section 3: Click Interaction Sound (On/Off + 3 Styles, always active) */}
        <div className="mb-6 p-4 rounded-2xl bg-stone-900/70 border border-cyan-500/35 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-xs font-black text-cyan-300">
              <MousePointerClick className="w-4 h-4 shrink-0" />
              <span>صوت النقر على كل خانة أو أيقونة (مفعل دوماً)</span>
            </div>

            <div className="flex items-center gap-1.5 bg-stone-950 p-1 rounded-xl border border-stone-800">
              <button
                type="button"
                onClick={() => handleToggleClickSound(true)}
                className={`min-h-[36px] px-3 py-1 rounded-lg text-[11px] font-black transition-all cursor-pointer ${
                  localSettings.clickSoundEnabled
                    ? 'bg-emerald-500 text-black shadow'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                يصدر صوت ✓
              </button>
              <button
                type="button"
                onClick={() => handleToggleClickSound(false)}
                className={`min-h-[36px] px-3 py-1 rounded-lg text-[11px] font-black transition-all cursor-pointer ${
                  !localSettings.clickSoundEnabled
                    ? 'bg-red-600 text-white shadow'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                بدون صوت (صامت)
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {CLICK_SOUND_OPTIONS.map((styleOpt) => {
              const isSelected = localSettings.clickSoundStyle === styleOpt.id && localSettings.clickSoundEnabled;
              return (
                <button
                  key={styleOpt.id}
                  type="button"
                  onClick={() => handleSelectClickStyle(styleOpt.id)}
                  className={`min-h-[44px] p-2.5 rounded-xl border text-right transition-all duration-200 cursor-pointer flex flex-col justify-between gap-1 active:scale-95 ${
                    isSelected
                      ? 'bg-cyan-500/20 border-cyan-400 text-white shadow-[0_0_14px_rgba(34,211,238,0.35)]'
                      : localSettings.clickSoundEnabled
                        ? 'bg-stone-950/80 border-stone-800 hover:border-cyan-500/40 text-gray-300'
                        : 'bg-stone-950/40 border-stone-800/60 text-gray-500 hover:border-cyan-500/30'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-black">{styleOpt.label}</span>
                    <span className="text-[10px] font-mono text-cyan-300 tabular-nums">{styleOpt.durationLabel}</span>
                  </div>
                  <span className="text-[10px] text-gray-400">{styleOpt.description}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Section 4: Alert Duration Choice */}
        <div className="mb-6">
          <label className="block text-xs font-bold text-yellow-400 mb-2 flex items-center gap-1.5">
            <Clock className="w-4 h-4" />
            مدة استمرار التنبيه عند وصول قصاصة جديدة:
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {[
              { label: '5 ثواني', val: 5 },
              { label: '10 ثواني', val: 10 },
              { label: '15 ثانية', val: 15 },
              { label: 'حتى الإغلاق', val: 0 },
            ].map((item) => {
              const isSelected = localSettings.durationSeconds === item.val;
              return (
                <button
                  key={item.val}
                  type="button"
                  onClick={() => {
                    audioService.playClick();
                    updateAndActivate((prev) => ({ ...prev, durationSeconds: item.val as 5 | 10 | 15 | 0 }));
                  }}
                  className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all duration-300 ${
                    isSelected
                      ? 'bg-yellow-500 text-black border-yellow-300 shadow-[0_0_15px_rgba(234,179,8,0.5)] scale-102'
                      : 'bg-stone-900 text-gray-400 border-stone-800 hover:border-stone-700'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Section 3: Automatic Check Frequency */}
        <div className="mb-6">
          <label className="block text-xs font-bold text-yellow-400 mb-2 flex items-center gap-1.5">
            <RefreshCw className="w-4 h-4" />
            تردد فحص التحديثات التلقائي:
          </label>
          <div className="grid grid-cols-3 gap-2">
            {[
              { label: 'كل ربع ساعة (15 دقيقة)', val: 15 },
              { label: 'كل نصف ساعة (30 دقيقة)', val: 30 },
              { label: 'كل ساعة كاملة (60 دقيقة)', val: 60 },
            ].map((item) => {
              const isSelected = localSettings.checkIntervalMinutes === item.val;
              return (
                <button
                  key={item.val}
                  type="button"
                  onClick={() => {
                    audioService.playClick();
                    setLocalSettings((prev) => ({
                      ...prev,
                      checkIntervalMinutes: item.val as 15 | 30 | 60,
                    }));
                  }}
                  className={`py-2 px-2.5 rounded-xl text-xs font-bold border transition-all duration-300 ${
                    isSelected
                      ? 'bg-red-600 text-white border-yellow-400 shadow-[0_0_15px_rgba(220,38,38,0.6)] scale-102'
                      : 'bg-stone-900 text-gray-400 border-stone-800 hover:border-stone-700'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Section 4: Backup & Prompt Export/Import */}
        <div className="mb-8 p-4 rounded-2xl bg-stone-900/60 border border-stone-800">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <div className="text-xs font-bold text-gray-200">النسخ الاحتياطي والبرومبت كاملاً (JSON)</div>
              <div className="text-[11px] text-gray-400">حفظ الإعدادات والمواصفات ومزامنتها في أي وقت</div>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleExport}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 border border-stone-700 text-yellow-400 text-xs font-bold transition-all active:scale-95"
              >
                <Download className="w-3.5 h-3.5" />
                <span>تنزيل البرومبت JSON</span>
              </button>

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 border border-stone-700 text-gray-300 hover:text-white text-xs font-bold transition-all active:scale-95"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>استيراد ملف</span>
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept=".json"
                className="hidden"
                onChange={handleImportFile}
              />
            </div>
          </div>
        </div>

        {/* Footer Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-stone-800">
          <button
            type="button"
            onClick={() => {
              audioService.playClick();
              onTriggerTestAlert();
            }}
            className="w-full sm:w-auto px-4 py-2.5 rounded-2xl bg-stone-900 hover:bg-stone-800 border border-stone-700 text-xs font-bold text-gray-300 hover:text-white transition-all active:scale-95 flex items-center justify-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-yellow-400" />
            <span>تجربة تنبيه حي</span>
          </button>

          {/* Dedicated glowing save button as requested */}
          <button
            type="button"
            onClick={handleSave}
            className={`w-full sm:w-auto px-6 py-2.5 rounded-2xl font-black text-xs transition-all duration-300 flex items-center justify-center gap-2 active:scale-95 ${
              savedSuccess
                ? 'bg-emerald-500 text-black border border-emerald-300 shadow-[0_0_20px_rgba(16,185,129,0.8)]'
                : 'bg-gradient-to-r from-yellow-500 via-amber-400 to-yellow-600 text-black border border-yellow-300 shadow-[0_0_25px_rgba(234,179,8,0.7)] hover:shadow-[0_0_35px_rgba(234,179,8,1)] animate-gold-pulse'
            }`}
          >
            {savedSuccess ? (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>تم الحفظ والتفعيل الفوري!</span>
              </>
            ) : (
              <>
                <Save className="w-4 h-4 animate-pulse" />
                <span>حفظ وتفعيل التحديث التلقائي دوماً</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
