/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ZoomIn, ZoomOut, RotateCcw, ChevronUp } from 'lucide-react';
import { WeeklyConcoursMatch } from '../types/promosport';
import { PinterestScoreboardCard } from './PinterestScoreboardCard';
import { audioService } from '../services/audioService';

interface Grille3DWheelViewProps {
  matches: WeeklyConcoursMatch[];
  lang: 'AR' | 'FR';
  isBettingLocked: boolean;
  selections: Record<number, ('1' | 'X' | '2')[]>;
  onToggleSelection: (matchId: number, sign: '1' | 'X' | '2') => void;
  getTeamName: (teamName: string, frName?: string) => string;
  onUserScrollMove?: () => void;
  onScrollHideTopBar?: () => void;
  goalFlashMatchIds?: Record<number, number>;
  topOverlayContent?: React.ReactNode;
}

const MIN_GRILLE_ZOOM = 0.3;
const MAX_GRILLE_ZOOM = 1.6;
const ZOOM_STEP = 0.1;
const GRILLE_ZOOM_STORAGE_KEY = 'promosport_grille_zoom_v1';

// Module-level vertical scroll persistence so top/bottom scroll stays locked across tab/sync updates
let persistedGrilleScrollTop = 0;

const clampZoom = (val: number): number => {
  const clamped = Math.min(MAX_GRILLE_ZOOM, Math.max(MIN_GRILLE_ZOOM, val));
  return Math.round(clamped * 100) / 100;
};

const loadInitialZoom = (): number => {
  try {
    if (typeof window === 'undefined' || !window.localStorage) return 1;
    const raw = window.localStorage.getItem(GRILLE_ZOOM_STORAGE_KEY);
    if (!raw) return 1;
    const parsed = Number(raw);
    return Number.isFinite(parsed) ? clampZoom(parsed) : 1;
  } catch {
    return 1;
  }
};

export const Grille3DWheelView: React.FC<Grille3DWheelViewProps> = ({
  matches,
  lang,
  isBettingLocked,
  selections,
  onToggleSelection,
  getTeamName,
  onUserScrollMove,
  onScrollHideTopBar,
  goalFlashMatchIds = {},
  topOverlayContent,
}) => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const zoomViewportRef = useRef<HTMLDivElement>(null);
  const matchesContentRef = useRef<HTMLDivElement>(null);
  const numericInputRef = useRef<HTMLInputElement>(null);

  const [zoom, setZoom] = useState<number>(loadInitialZoom);
  const [isZoomBarOpen, setIsZoomBarOpen] = useState<boolean>(true);
  const [zoomTextInput, setZoomTextInput] = useState<string>(() =>
    String(Math.round(loadInitialZoom() * 100))
  );
  const [viewportWidth, setViewportWidth] = useState<number>(0);
  const [unscaledHeight, setUnscaledHeight] = useState<number>(0);

  // Scroll auto-hide refs (finger zoom disabled strictly per user request)
  const isZoomBarOpenRef = useRef<boolean>(isZoomBarOpen);
  isZoomBarOpenRef.current = isZoomBarOpen;
  const suppressScrollHideUntilRef = useRef<number>(Date.now() + 500);
  const lastScrollTopRef = useRef<number>(persistedGrilleScrollTop);
  const touchStartYRef = useRef<number | null>(null);
  const zoomRef = useRef<number>(zoom);
  zoomRef.current = zoom;

  const hideFloatingBarsOnScroll = useCallback(() => {
    if (Date.now() < suppressScrollHideUntilRef.current) return;
    suppressScrollHideUntilRef.current = Date.now() + 350;
    if (isZoomBarOpenRef.current) {
      setIsZoomBarOpen(false);
    }
    onScrollHideTopBar?.();
  }, [onScrollHideTopBar]);

  const openZoomBarManually = useCallback(() => {
    audioService.playClick();
    suppressScrollHideUntilRef.current = Date.now() + 450;
    setIsZoomBarOpen(true);
  }, []);

  const closeZoomBarManually = useCallback(() => {
    audioService.playClick();
    suppressScrollHideUntilRef.current = Date.now() + 450;
    setIsZoomBarOpen(false);
  }, []);

  const updateZoom = useCallback((next: number | ((prev: number) => number)) => {
    suppressScrollHideUntilRef.current = Date.now() + 450;
    setZoom((prev) => {
      const resolved = typeof next === 'function' ? next(prev) : next;
      const clamped = clampZoom(resolved);
      setZoomTextInput(String(Math.round(clamped * 100)));
      try {
        if (typeof window !== 'undefined' && window.localStorage) {
          window.localStorage.setItem(GRILLE_ZOOM_STORAGE_KEY, String(clamped));
        }
      } catch {
        // ignore storage errors
      }
      return clamped;
    });
  }, []);

  const handleApplyNumericZoom = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    audioService.playClick();
    const cleaned = zoomTextInput.replace(/[^\d]/g, '');
    const parsed = Number(cleaned);
    if (cleaned.length > 0 && Number.isFinite(parsed) && parsed > 0) {
      const clampedPct = Math.min(160, Math.max(30, Math.round(parsed)));
      updateZoom(clampedPct / 100);
      setZoomTextInput(String(clampedPct));
    } else {
      setZoomTextInput(String(Math.round(zoom * 100)));
    }
    numericInputRef.current?.blur();
  };

  // Measure unscaled grille dimensions (Android 6+ safe: ResizeObserver optional with rAF/resize fallback)
  const measureGrilleBox = useCallback(() => {
    if (zoomViewportRef.current) {
      const nextWidth = zoomViewportRef.current.clientWidth;
      if (nextWidth > 0) {
        setViewportWidth((prev) => (prev !== nextWidth ? nextWidth : prev));
      }
    }
    if (matchesContentRef.current) {
      const nextHeight = matchesContentRef.current.offsetHeight;
      if (nextHeight > 0) {
        setUnscaledHeight((prev) => (prev !== nextHeight ? nextHeight : prev));
      }
    }
  }, []);

  useEffect(() => {
    const rafId = window.requestAnimationFrame(measureGrilleBox);
    window.addEventListener('resize', measureGrilleBox);

    let observer: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined') {
      observer = new ResizeObserver(() => {
        measureGrilleBox();
      });
      if (zoomViewportRef.current) observer.observe(zoomViewportRef.current);
      if (matchesContentRef.current) observer.observe(matchesContentRef.current);
    }

    return () => {
      window.cancelAnimationFrame(rafId);
      window.removeEventListener('resize', measureGrilleBox);
      observer?.disconnect();
    };
  }, [measureGrilleBox, zoom, matches.length, lang, isBettingLocked]);

  // Restore saved vertical scroll offset cleanly on mount & persist user scroll position
  useEffect(() => {
    if (scrollContainerRef.current && persistedGrilleScrollTop > 0) {
      suppressScrollHideUntilRef.current = Date.now() + 500;
      const rafId = window.requestAnimationFrame(() => {
        if (scrollContainerRef.current) {
          scrollContainerRef.current.scrollTop = persistedGrilleScrollTop;
          lastScrollTopRef.current = persistedGrilleScrollTop;
        }
      });
      return () => window.cancelAnimationFrame(rafId);
    }
    return undefined;
  }, []);

  const handleContainerScroll = () => {
    if (!scrollContainerRef.current) return;
    const nextTop = scrollContainerRef.current.scrollTop;
    const delta = Math.abs(nextTop - lastScrollTopRef.current);
    persistedGrilleScrollTop = nextTop;
    lastScrollTopRef.current = nextTop;
    if (delta > 8) {
      hideFloatingBarsOnScroll();
    }
  };

  // Desktop Ctrl+Wheel / trackpad pinch zoom strictly on the grille area (touch/finger zoom stays OFF)
  useEffect(() => {
    const el = zoomViewportRef.current;
    if (!el) return;

    const handleWheel = (e: WheelEvent) => {
      if (!e.ctrlKey && !e.metaKey) return;
      e.preventDefault();
      const delta = -e.deltaY * 0.0025;
      if (Math.abs(delta) > 0.001) {
        updateZoom((prev) => prev + delta);
      }
    };

    el.addEventListener('wheel', handleWheel, { passive: false });
    return () => {
      el.removeEventListener('wheel', handleWheel);
    };
  }, [updateZoom]);

  // Reset horizontal scroll when zooming back to <= 100%
  useEffect(() => {
    if (zoom <= 1.001 && zoomViewportRef.current && zoomViewportRef.current.scrollLeft !== 0) {
      zoomViewportRef.current.scrollLeft = 0;
    }
  }, [zoom]);

  // Mouse drag-to-scroll support for desktop (vertical + horizontal when zoomed in)
  const isMouseDownRef = useRef<boolean>(false);
  const startYRef = useRef<number>(0);
  const startXRef = useRef<number>(0);
  const scrollTopRef = useRef<number>(0);
  const scrollLeftRef = useRef<number>(0);

  const handleMouseDown = (e: React.MouseEvent) => {
    if (!scrollContainerRef.current) return;
    if ((e.target as HTMLElement | null)?.closest('button, input, a, select, textarea')) return;
    isMouseDownRef.current = true;
    startYRef.current = e.pageY - scrollContainerRef.current.offsetTop;
    scrollTopRef.current = scrollContainerRef.current.scrollTop;
    if (zoomViewportRef.current) {
      startXRef.current = e.pageX - zoomViewportRef.current.offsetLeft;
      scrollLeftRef.current = zoomViewportRef.current.scrollLeft;
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isMouseDownRef.current || !scrollContainerRef.current) return;
    e.preventDefault();
    const y = e.pageY - scrollContainerRef.current.offsetTop;
    const deltaY = y - startYRef.current;
    if (Math.abs(deltaY) > 10) {
      hideFloatingBarsOnScroll();
    }
    if (Math.abs(deltaY) > 4) {
      onUserScrollMove?.();
    }
    scrollContainerRef.current.scrollTop = scrollTopRef.current - deltaY * 1.3;

    if (zoomRef.current > 1.001 && zoomViewportRef.current) {
      const x = e.pageX - zoomViewportRef.current.offsetLeft;
      const deltaX = x - startXRef.current;
      zoomViewportRef.current.scrollLeft = scrollLeftRef.current - deltaX * 1.2;
    }
  };

  const handleMouseUp = () => {
    isMouseDownRef.current = false;
  };

  const isDefaultZoom = Math.abs(zoom - 1) < 0.01;
  const isZoomedIn = zoom > 1.001;
  const isZoomedOut = zoom < 0.999;
  const zoomPercent = Math.round(zoom * 100);
  const trackProgressPct = Math.min(100, Math.max(0, ((zoomPercent - 30) / (160 - 30)) * 100));
  const scaledHeight = unscaledHeight > 0 ? Math.ceil(unscaledHeight * zoom) : 0;

  // When zoomed out (30%..99%), expand unscaled layout width = viewportWidth / zoom
  // so scaled horizontal width = 100% edge-to-edge across the entire page while height shrinks down to 30%
  const unscaledEdgeToEdgeWidth =
    isZoomedOut && viewportWidth > 0
      ? Math.round(viewportWidth / zoom)
      : viewportWidth > 0
      ? viewportWidth
      : 0;

  return (
    <div className="relative w-full h-full flex-1 flex flex-col select-none overflow-hidden">
      {/* MANUAL REOPEN BUTTON FOR ZOOM BAR (Top-Left Corner so it never collides with Centered Top Ribbon Reopen Icon) */}
      {!isZoomBarOpen && (
        <button
          type="button"
          data-no-flash="true"
          onClick={openZoomBarManually}
          title={lang === 'AR' ? 'فتح شريط زوم القصاصة يدوياً' : 'Ouvrir le zoom manuellement'}
          aria-label="فتح أيقونة زوم القصاصة"
          className="absolute top-1.5 left-1.5 z-40 min-h-[36px] px-2.5 py-1 rounded-full bg-transparent hover:bg-white/10 backdrop-blur-[2px] border border-cyan-300/75 text-cyan-100 shadow-[0_2px_12px_rgba(0,0,0,0.65)] flex items-center gap-1 active:scale-95 transition-all cursor-pointer"
        >
          <ZoomIn className="w-3.5 h-3.5 text-yellow-300 shrink-0" />
          <span className="text-[10.5px] font-black whitespace-nowrap drop-shadow-[0_1px_3px_rgba(0,0,0,0.98)]">
            {lang === 'AR' ? 'زوم' : 'Zoom'}
          </span>
          <span className="font-mono tabular-nums text-[10.5px] font-black text-yellow-300" dir="ltr">
            {zoomPercent}%
          </span>
        </button>
      )}

      {/* TOP TRANSPARENT FLOATING OVERLAY STACK OVER THE 13 MATCHES (يمر تحتها هيكل كل المباريات) */}
      <div className="absolute top-0 inset-x-0 z-30 pointer-events-none flex flex-col">
        {/* 1. Unified Grand Prize + Tabs + Save/Clear Top Bar (or Centered Transparent Reopen Icon when closed) */}
        {topOverlayContent}

        {/* 2. Compact Full Edge-to-Edge Transparent Zoom Bar (30% - 160%, Zero Finger Zoom) */}
        {isZoomBarOpen && (
          <div
            data-no-flash="true"
            className="pointer-events-auto w-full px-0 bg-transparent border-b border-white/20"
          >
            <form
              onSubmit={handleApplyNumericZoom}
              dir="ltr"
              className="w-full flex items-center gap-1 py-1 px-0"
            >
              {/* Left Edge: Zoom Out (-) */}
              <button
                type="button"
                data-no-flash="true"
                disabled={zoom <= MIN_GRILLE_ZOOM}
                onClick={() => {
                  audioService.playClick();
                  updateZoom((prev) => prev - ZOOM_STEP);
                }}
                title={lang === 'AR' ? 'تصغير القصاصة حتى 30%' : 'Dézoomer (30%)'}
                aria-label="تصغير القصاصة"
                className="min-w-[38px] h-[36px] px-1.5 bg-[#040c1d]/70 hover:bg-[#0b1f42] border-y border-r border-sky-400/75 text-sky-100 hover:text-white flex items-center justify-center active:scale-95 transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer shrink-0 rounded-r-xl"
              >
                <ZoomOut className="w-4 h-4" />
              </button>

              {/* Center Visual Progress Bar (read-only indicator, zero finger interaction) */}
              <div className="relative flex-1 min-w-[28px] h-[36px] flex items-center px-1.5 pointer-events-none select-none">
                <div className="relative w-full h-2.5 rounded-full bg-black/50 border border-sky-400/50 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-cyan-400 via-yellow-400 to-amber-500 transition-all duration-150"
                    style={{ width: `${trackProgressPct}%` }}
                  />
                </div>
                <div
                  className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-gradient-to-b from-yellow-300 to-amber-500 border-2 border-white shadow-[0_0_8px_rgba(250,204,21,0.85)] transition-all duration-150"
                  style={{ left: `calc(${trackProgressPct}% * 0.88 + 6%)` }}
                />
              </div>

              {/* Numeric Entry + Execute ("تنفيذ") + Reset 100% */}
              <div className="flex items-center gap-1 shrink-0">
                <div className="relative flex items-center">
                  <input
                    ref={numericInputRef}
                    type="text"
                    inputMode="numeric"
                    pattern="[0-9]*"
                    maxLength={3}
                    value={zoomTextInput}
                    onChange={(e) => setZoomTextInput(e.target.value.replace(/[^\d]/g, '').slice(0, 3))}
                    onMouseDown={(e) => e.stopPropagation()}
                    onClick={(e) => e.stopPropagation()}
                    aria-label="كتابة نسبة الزوم بالأرقام من 30 إلى 160"
                    placeholder="30-160"
                    style={{ userSelect: 'text', WebkitUserSelect: 'text' }}
                    className="w-[54px] h-[34px] pr-4 pl-1 rounded-lg bg-black/65 border border-sky-400/80 focus:border-yellow-400 text-center font-mono tabular-nums text-xs font-black text-yellow-300 outline-none select-text"
                  />
                  <span className="absolute right-1 text-[10px] font-black text-gray-300 pointer-events-none">
                    %
                  </span>
                </div>

                <button
                  type="submit"
                  data-no-flash="true"
                  className="min-h-[34px] px-2.5 rounded-lg bg-gradient-to-r from-yellow-400 to-amber-500 hover:brightness-105 text-black font-black text-[11px] shadow active:scale-95 transition-all cursor-pointer whitespace-nowrap"
                >
                  {lang === 'AR' ? 'تنفيذ' : 'OK'}
                </button>

                {!isDefaultZoom && (
                  <button
                    type="button"
                    data-no-flash="true"
                    onClick={() => {
                      audioService.playClick();
                      updateZoom(1);
                    }}
                    title={lang === 'AR' ? 'إعادة الضبط 100%' : 'Reset 100%'}
                    aria-label="إعادة الضبط 100%"
                    className="min-w-[30px] h-[34px] rounded-lg bg-black/60 hover:bg-amber-500/35 border border-yellow-400/70 text-yellow-300 flex items-center justify-center active:scale-95 transition-all cursor-pointer shrink-0"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                )}

                <button
                  type="button"
                  data-no-flash="true"
                  onClick={closeZoomBarManually}
                  title={lang === 'AR' ? 'إخفاء شريط الزوم' : 'Masquer'}
                  aria-label="إخفاء شريط الزوم"
                  className="min-w-[28px] h-[34px] rounded-lg bg-black/50 hover:bg-white/15 border border-white/30 text-white flex items-center justify-center active:scale-95 transition-all cursor-pointer shrink-0"
                >
                  <ChevronUp className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Right Edge: Zoom In (+) */}
              <button
                type="button"
                data-no-flash="true"
                disabled={zoom >= MAX_GRILLE_ZOOM}
                onClick={() => {
                  audioService.playClick();
                  updateZoom((prev) => prev + ZOOM_STEP);
                }}
                title={lang === 'AR' ? 'تكبير القصاصة' : 'Zoomer'}
                aria-label="تكبير القصاصة"
                className="min-w-[38px] h-[36px] px-1.5 bg-[#040c1d]/70 hover:bg-[#0b1f42] border-y border-l border-sky-400/75 text-sky-100 hover:text-white flex items-center justify-center active:scale-95 transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer shrink-0 rounded-l-xl"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
            </form>
          </div>
        )}
      </div>

      {/* FULL-HEIGHT VERTICAL SCROLL CONTAINER (يمر هيكل المباريات تحت الشريط العلوي والسفلي) */}
      <div
        ref={scrollContainerRef}
        onScroll={handleContainerScroll}
        onTouchStart={(e) => {
          if (e.touches.length === 1) {
            touchStartYRef.current = e.touches[0].clientY;
          } else {
            touchStartYRef.current = null;
          }
        }}
        onTouchMove={(e) => {
          if (e.touches.length === 1 && touchStartYRef.current !== null) {
            if (Math.abs(e.touches[0].clientY - touchStartYRef.current) > 14) {
              hideFloatingBarsOnScroll();
            }
          }
        }}
        onTouchEnd={() => {
          touchStartYRef.current = null;
        }}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        className="flex-1 overflow-y-auto overflow-x-hidden overscroll-contain cursor-grab active:cursor-grabbing [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]"
        style={{
          WebkitOverflowScrolling: 'touch',
        }}
      >
        {/* ZOOMABLE EDGE-TO-EDGE 13-MATCH GRILLE (القصاصة الـ 13 بالكامل، بدون زوم بالإصبع) */}
        <div
          ref={zoomViewportRef}
          dir="ltr"
          className={`w-full ${isZoomedIn ? 'overflow-x-auto' : 'overflow-x-hidden'} [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]`}
          style={{
            touchAction: isZoomedIn ? 'pan-x pan-y' : 'pan-y',
            WebkitOverflowScrolling: 'touch',
          }}
        >
          <div
            style={{
              position: 'relative',
              width:
                isZoomedIn && viewportWidth > 0
                  ? `${Math.ceil(viewportWidth * zoom)}px`
                  : '100%',
              height: !isDefaultZoom && scaledHeight > 0 ? `${scaledHeight}px` : 'auto',
            }}
          >
            <div
              ref={matchesContentRef}
              className="px-0 pt-[195px] sm:pt-[180px] pb-[90px] space-y-4"
              style={
                isDefaultZoom
                  ? {
                      position: 'relative',
                      width: '100%',
                    }
                  : {
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      width: unscaledEdgeToEdgeWidth > 0 ? `${unscaledEdgeToEdgeWidth}px` : '100%',
                      transform: `scale(${zoom})`,
                      transformOrigin: 'top left',
                      willChange: 'transform',
                    }
              }
            >
              {matches.map((match) => {
                const userChoices = selections[match.id] || [];
                const justScoredGoal = Boolean(goalFlashMatchIds[match.id]);

                return (
                  <div
                    id={`grille-match-${match.id}`}
                    key={match.id}
                    className="relative w-full"
                    dir="ltr"
                  >
                    <PinterestScoreboardCard
                      match={match}
                      lang={lang}
                      mode="fill"
                      isBettingLocked={isBettingLocked}
                      selections={userChoices}
                      onToggleSelection={onToggleSelection}
                      getTeamName={getTeamName}
                      justScoredGoal={justScoredGoal}
                    />
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
