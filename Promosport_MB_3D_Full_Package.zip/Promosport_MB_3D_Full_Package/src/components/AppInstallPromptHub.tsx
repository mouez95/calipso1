import React, { useEffect, useState } from 'react';
import { CalendarDays, Download, Smartphone, Ticket } from 'lucide-react';
import { AppSettings, UserBetSlip, WeeklyConcours } from '../types/promosport';

interface AppInstallPromptHubProps {
  settings: AppSettings;
  userSlips: UserBetSlip[];
  concours: WeeklyConcours;
}

type InstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
};

export const AppInstallPromptHub: React.FC<AppInstallPromptHubProps> = ({ settings, userSlips, concours }) => {
  const [installPrompt, setInstallPrompt] = useState<InstallPromptEvent | null>(null);
  const [installMessage, setInstallMessage] = useState('');

  useEffect(() => {
    const handleInstallPrompt = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as InstallPromptEvent);
    };
    window.addEventListener('beforeinstallprompt', handleInstallPrompt);
    return () => window.removeEventListener('beforeinstallprompt', handleInstallPrompt);
  }, []);

  const handleInstall = async () => {
    if (!installPrompt) {
      setInstallMessage('لإضافة التطبيق إلى الشاشة الرئيسية، افتح قائمة المتصفح واختر «تثبيت التطبيق» أو «إضافة إلى الشاشة الرئيسية».');
      return;
    }
    await installPrompt.prompt();
    const choice = await installPrompt.userChoice;
    setInstallMessage(choice.outcome === 'accepted' ? 'بدأ تثبيت التطبيق.' : 'يمكنك التثبيت لاحقاً من قائمة المتصفح.');
    setInstallPrompt(null);
  };

  return (
    <section className="w-full rounded-2xl border border-cyan-500/30 bg-[#061126]/90 p-4 text-right text-white space-y-4">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-11 h-11 rounded-xl border border-cyan-400/40 bg-cyan-500/10 text-cyan-200 flex items-center justify-center shrink-0">
            <Smartphone className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <h2 className="text-sm font-black text-cyan-100 truncate">{settings.appName || 'Promosport MB 3D'}</h2>
            <p className="text-[11px] text-gray-400">التثبيت وملخص النشاط</p>
          </div>
        </div>
        <button type="button" onClick={() => void handleInstall()} className="min-h-[40px] px-3 rounded-xl bg-cyan-400 text-black font-black text-xs flex items-center gap-2 hover:bg-cyan-300 active:scale-95 transition-all">
          <Download className="w-4 h-4" /> تثبيت
        </button>
      </div>

      {installMessage && <p role="status" className="rounded-xl border border-cyan-500/20 bg-cyan-500/5 p-3 text-[11px] leading-relaxed text-cyan-100">{installMessage}</p>}

      <div className="grid grid-cols-2 gap-2">
        <div className="rounded-xl border border-white/10 bg-black/25 p-3 flex items-center gap-2">
          <Ticket className="w-4 h-4 text-yellow-300 shrink-0" />
          <div><p className="text-[10px] text-gray-400">القصاصة الحالية</p><p className="text-sm font-black text-yellow-200">#{concours.number}</p></div>
        </div>
        <div className="rounded-xl border border-white/10 bg-black/25 p-3 flex items-center gap-2">
          <CalendarDays className="w-4 h-4 text-emerald-300 shrink-0" />
          <div><p className="text-[10px] text-gray-400">قصاصاتي المحفوظة</p><p className="text-sm font-black text-emerald-200">{userSlips.length}</p></div>
        </div>
      </div>
    </section>
  );
};
