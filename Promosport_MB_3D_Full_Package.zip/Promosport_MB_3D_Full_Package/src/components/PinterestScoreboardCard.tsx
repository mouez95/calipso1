/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Trophy, Clock, Layers, CheckCircle2, XCircle, Sparkles, Flame, Star, Tv } from 'lucide-react';
import { WeeklyConcoursMatch } from '../types/promosport';
import { parseMatchScore } from '../services/matchLiveService';
import { TeamCrest } from './TeamCrest';
import { ChronometerScore } from './ChronometerScore';
import {
  formatMatchPlusOneDate,
  formatMatchUtcPlusOneTime,
} from '../services/timeUtils';

export interface PinterestScoreboardCardProps {
  match: WeeklyConcoursMatch;
  lang: 'AR' | 'FR';
  mode: 'fill' | 'slip' | 'tirage' | 'home' | 'live';
  isBettingLocked?: boolean;
  selections?: ('1' | 'X' | '2')[];
  onToggleSelection?: (matchId: number, sign: '1' | 'X' | '2') => void;
  slipChoices?: ('1' | 'X' | '2')[];
  isEditingSlip?: boolean;
  getTeamName?: (teamName: string, frName?: string) => string;
  justScoredGoal?: boolean;
  isFavorite?: boolean;
  onToggleFavorite?: () => void;
  isWatchingLive?: boolean;
  onToggleWatchLive?: () => void;
}

export const PinterestScoreboardCard: React.FC<PinterestScoreboardCardProps> = ({
  match,
  lang,
  mode,
  isBettingLocked = false,
  selections = [],
  onToggleSelection,
  slipChoices = [],
  isEditingSlip = false,
  getTeamName,
  justScoredGoal = false,
  isFavorite = false,
  onToggleFavorite,
  isWatchingLive = false,
  onToggleWatchLive,
}) => {
  const [homeImgFailed, setHomeImgFailed] = useState(false);
  const [awayImgFailed, setAwayImgFailed] = useState(false);

  useEffect(() => {
    setHomeImgFailed(false);
  }, [match.homeCrestUrl]);

  useEffect(() => {
    setAwayImgFailed(false);
  }, [match.awayCrestUrl]);

  const resolveName = (ar: string, fr?: string) => {
    if (getTeamName) return getTeamName(ar, fr);
    return lang === 'AR' ? ar : fr || ar;
  };

  const localName = resolveName(match.homeTeam, match.homeTeamFr);
  const visitorName = resolveName(match.awayTeam, match.awayTeamFr);
  const competitionName =
    lang === 'AR'
      ? match.competition || 'النتيجة الرسمية'
      : match.competitionFr || match.competition || 'SPORT SCORE';

  const isDelayed = Boolean(match.isDelayed);
  const isFinished = !isDelayed && match.status === 'finished';
  const isLive = !isDelayed && match.status === 'live';
  const hasResult = !isDelayed && match.result !== null;

  const activeChoices = mode === 'slip' ? slipChoices : selections;
  const isCorrect = mode === 'slip' && hasResult && activeChoices.includes(match.result!);

  const parsedScore = isDelayed ? null : parseMatchScore(match);
  const homeScore = parsedScore ? parsedScore.home : '';
  const awayScore = parsedScore ? parsedScore.away : '';

  const matchColumnLabel =
    activeChoices.length === 3
      ? lang === 'AR'
        ? 'ثلاثي (3 أعمدة)'
        : 'Triple (3)'
      : activeChoices.length === 2
      ? lang === 'AR'
        ? 'ثنائي (عمودان)'
        : 'Double (2)'
      : activeChoices.length === 1
      ? lang === 'AR'
        ? 'فردي (عمود واحد)'
        : 'Simple (1)'
      : lang === 'AR'
      ? 'بدون تحديد'
      : 'Non choisi';

  const isCompact50 = mode === 'live';
  const ledSizeCls = isCompact50 ? 'h-2 w-2' : 'h-3.5 w-3.5';
  const plusOneTimeLabel = formatMatchUtcPlusOneTime(match);
  const plusOneDateLabel = formatMatchPlusOneDate(match);

  // Single radiant notification LED strictly in the top center metallic notch beside MATCH #N
  const renderIndicatorLed = () => {
    if (isDelayed) {
      return (
        <span className={`relative flex ${ledSizeCls} shrink-0`} title="مقابلة مؤجلة / قيد التحديث">
          <span className={`relative inline-flex rounded-full ${ledSizeCls} bg-gradient-to-br from-amber-200 via-amber-400 to-orange-600 shadow-[0_0_10px_2px_rgba(245,158,11,0.8)] border border-amber-100 items-center justify-center`}>
            <span className="w-1 h-1 rounded-full bg-white/95 -translate-x-0.5 -translate-y-0.5" />
          </span>
        </span>
      );
    }
    if (isLive) {
      return (
        <span className={`relative flex ${ledSizeCls} shrink-0`} title="المقابلة جارية الآن (مباشر)">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-300 opacity-90" />
          <span className={`relative inline-flex rounded-full ${ledSizeCls} bg-gradient-to-br from-emerald-200 via-emerald-400 to-green-600 shadow-[0_0_14px_3px_rgba(16,185,129,0.98),inset_0_1px_2px_rgba(255,255,255,0.95)] border border-white items-center justify-center`}>
            <span className="w-1 h-1 rounded-full bg-white/95 -translate-x-0.5 -translate-y-0.5" />
          </span>
        </span>
      );
    }
    if (isFinished) {
      return (
        <span className={`relative flex ${ledSizeCls} shrink-0`} title="انتهت المقابلة">
          <span className="animate-pulse absolute -inset-0.5 rounded-full bg-yellow-300/60 blur-[2px]" />
          <span className={`relative inline-flex rounded-full ${ledSizeCls} bg-gradient-to-br from-yellow-100 via-yellow-300 to-amber-500 shadow-[0_0_14px_3px_rgba(250,204,21,0.95),inset_0_1px_2px_rgba(255,255,255,0.95)] border border-yellow-100 items-center justify-center`}>
            <span className="w-1 h-1 rounded-full bg-white/95 -translate-x-0.5 -translate-y-0.5" />
          </span>
        </span>
      );
    }
    return (
      <span className={`relative flex ${ledSizeCls} shrink-0`} title="في انتظار بداية المقابلة">
        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-85" />
        <span className={`relative inline-flex rounded-full ${ledSizeCls} bg-gradient-to-br from-rose-200 via-red-500 to-red-700 shadow-[0_0_14px_3px_rgba(239,68,68,0.95),inset_0_1px_2px_rgba(255,255,255,0.95)] border border-rose-100 animate-pulse items-center justify-center`}>
          <span className="w-1 h-1 rounded-full bg-white/95 -translate-x-0.5 -translate-y-0.5" />
        </span>
      </span>
    );
  };

  const showInteractive1X2 =
    mode === 'fill' && !isBettingLocked && !isLive && !isFinished && !isDelayed && parsedScore === null;
  const showScoreDisplay = !showInteractive1X2;
  const displayScoreDash =
    !isDelayed &&
    parsedScore !== null &&
    (isLive || isFinished || mode === 'tirage' || mode === 'home' || mode === 'live')
      ? `${homeScore}-${awayScore}`
      : '- - -';

  const renderTeamEmblem = (
    crestUrl: string | undefined,
    imgFailed: boolean,
    onFail: () => void,
    teamName: string,
    logoCode: string
  ) => {
    if (crestUrl && !imgFailed) {
      return (
        <img
          src={crestUrl}
          alt={teamName}
          referrerPolicy="no-referrer"
          loading="lazy"
          onError={onFail}
          className="w-full h-full object-contain rounded-full select-none"
        />
      );
    }
    return <TeamCrest teamName={teamName} logoCode={logoCode} size="md" />;
  };

  return (
    <div className="relative w-full select-none" dir="ltr">
      {/* 1. TOP CENTERED DARK METALLIC ARCHED NOTCH (Matching exact SPORT SCORE dome crown in reference image) */}
      <div className={`relative z-10 flex justify-center pointer-events-none ${isCompact50 ? '-mb-[2px] px-2' : '-mb-[3px] px-4'}`}>
        <div
          data-flash-icon="true"
          className={`pointer-events-auto relative flex items-center justify-center bg-gradient-to-b from-[#3b424d] via-[#1c2026] to-[#0b0d11] shadow-[0_-4px_14px_rgba(0,0,0,0.65),inset_0_1px_1px_rgba(255,255,255,0.45)] ${
            isCompact50
              ? 'gap-1 px-2.5 sm:px-3.5 pt-1 pb-0.5 rounded-t-lg border-t border-x border-slate-300/80'
              : 'gap-2 px-5 sm:px-7 pt-2 pb-1.5 rounded-t-xl border-t-2 border-x-2 border-slate-300/80'
          }`}
          style={{
            clipPath:
              'polygon(0% 18%, 22% 18%, 32% 0%, 68% 0%, 78% 18%, 100% 18%, 100% 100%, 0% 100%)',
          }}
        >
          {renderIndicatorLed()}
          <span
            className={`font-black uppercase tracking-wider text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)] ${
              isCompact50 ? 'text-[8.5px] sm:text-[9.5px]' : 'text-[13px] sm:text-[14px]'
            }`}
          >
            {isCompact50 ? '#' : 'MATCH '}
            <span className="text-yellow-200">{isCompact50 ? match.id : `#${match.id}`}</span>
          </span>
          <span className={`text-slate-400 ${isCompact50 ? 'text-[8px]' : 'text-[10px]'}`}>•</span>
          <span
            className={`font-bold text-cyan-200 uppercase truncate ${
              isCompact50
                ? 'text-[8px] sm:text-[9px] max-w-[100px] sm:max-w-[130px]'
                : 'text-[10px] sm:text-[11px] max-w-[140px] sm:max-w-[200px]'
            }`}
          >
            {competitionName}
          </span>
        </div>
      </div>

      {/* 2. MAIN WINGED ROYAL BLUE CHASSIS + CURVED SILVER CHROME CRADLE BEZEL */}
      <div className="relative z-20 w-full">
        {/* Outer Thick 3D Silver Chrome Cradle Frame hugging sides & bottom curve */}
        <div
          className={`relative w-full bg-gradient-to-b from-[#f1f5f9] via-[#94a3b8] to-[#cbd5e1] shadow-[0_10px_28px_rgba(0,0,0,0.82),inset_0_2px_3px_rgba(255,255,255,0.95)] ${
            isCompact50
              ? 'p-[2px] pb-[3.5px] rounded-t-[8px] rounded-b-[16px]'
              : 'p-[3px] pb-[7px] rounded-t-[14px] rounded-b-[30px]'
          } ${
            isWatchingLive && mode === 'live'
              ? 'ring-2 ring-emerald-400 shadow-[0_0_20px_rgba(16,185,129,0.55)]'
              : ''
          }`}
        >
          {/* Inner Royal-Blue Wing Bar */}
          <div
            className={`relative w-full bg-gradient-to-b from-[#1a7dff] via-[#0557df] to-[#00349e] shadow-[inset_0_2px_6px_rgba(255,255,255,0.55),inset_0_-6px_14px_rgba(0,18,66,0.75)] overflow-visible flex items-center justify-between ${
              isCompact50
                ? 'min-h-[38px] sm:min-h-[44px] rounded-t-[6px] rounded-b-[13px] px-1.5 sm:px-2.5 py-1'
                : 'min-h-[72px] min-[370px]:min-h-[76px] sm:min-h-[88px] rounded-t-[11px] rounded-b-[24px] px-2.5 min-[370px]:px-3 sm:px-5 py-2'
            }`}
          >
            {/* Glossy Specular Glass Reflection along Top Half */}
            <div
              className={`absolute top-0 inset-x-0 h-[48%] bg-gradient-to-b from-white/35 via-white/10 to-transparent pointer-events-none ${
                isCompact50 ? 'rounded-t-[6px]' : 'rounded-t-[11px]'
              }`}
            />

            {/* Diagonal Silver Metallic Wing Stripes (Matching left/right slashes in Pinterest image) */}
            <div
              className={`absolute top-0 bottom-0 bg-gradient-to-b from-slate-100 via-slate-300 to-slate-500 opacity-95 shadow-[0_0_8px_rgba(255,255,255,0.65)] pointer-events-none ${
                isCompact50
                  ? 'left-1 sm:left-2 w-[3px] sm:w-[4px]'
                  : 'left-2 min-[370px]:left-2.5 sm:left-4 w-1.5 min-[370px]:w-2 sm:w-2.5'
              }`}
              style={{ transform: 'skewX(-18deg)' }}
            />
            <div
              className={`absolute top-0 bottom-0 bg-gradient-to-b from-slate-100 via-slate-300 to-slate-500 opacity-95 shadow-[0_0_8px_rgba(255,255,255,0.65)] pointer-events-none ${
                isCompact50
                  ? 'right-1 sm:right-2 w-[3px] sm:w-[4px]'
                  : 'right-2 min-[370px]:right-2.5 sm:right-4 w-1.5 min-[370px]:w-2 sm:w-2.5'
              }`}
              style={{ transform: 'skewX(18deg)' }}
            />

            {/* LEFT WING: LOCAL TEAM (الفريق المحلي دائماً على اليسار) */}
            <div
              className={`relative z-10 flex items-center flex-1 min-w-0 justify-start ${
                isCompact50
                  ? 'gap-1 sm:gap-1.5 pl-1.5 sm:pl-2.5 pr-0.5'
                  : 'gap-1.5 min-[370px]:gap-2 sm:gap-3 pl-2.5 min-[370px]:pl-3 sm:pl-5 pr-0.5 sm:pr-1'
              }`}
            >
              <div
                data-flash-icon="true"
                className={`shrink-0 rounded-full bg-[#030c22] shadow-[0_2px_4px_rgba(0,0,0,0.65)] flex items-center justify-center overflow-hidden ${
                  isCompact50
                    ? 'w-5 h-5 min-[370px]:w-6 min-[370px]:h-6 sm:w-7 sm:h-7 border border-white p-0.5'
                    : 'w-10 h-10 min-[370px]:w-11 min-[370px]:h-11 sm:w-12 sm:h-12 border-2 border-white p-1'
                }`}
              >
                {renderTeamEmblem(
                  match.homeCrestUrl,
                  homeImgFailed,
                  () => setHomeImgFailed(true),
                  match.homeTeam,
                  match.homeLogo
                )}
              </div>
              <div className="min-w-0 text-left">
                <div
                  className={`font-black text-white uppercase tracking-wide drop-shadow-[0_2px_5px_rgba(0,0,0,0.95)] leading-tight ${
                    isCompact50
                      ? 'text-[10px] min-[370px]:text-[11px] sm:text-xs line-clamp-1'
                      : 'text-[12px] min-[370px]:text-[13.5px] sm:text-lg md:text-xl line-clamp-2'
                  }`}
                >
                  {localName}
                </div>
                {!isCompact50 && (
                  <span className="text-[9.5px] min-[370px]:text-[10px] sm:text-[11px] font-extrabold text-sky-100/95 block drop-shadow-sm">
                    {lang === 'AR' ? 'محلي (1)' : 'Domicile (1)'}
                  </span>
                )}
              </div>
            </div>

            {/* CENTER PROTRUDING CIRCULAR/OVAL CHROME-BEZEL DIAL MEDALLION */}
            <div
              className={`relative z-30 shrink-0 flex flex-col items-center justify-center ${
                isCompact50 ? 'mx-0.5 sm:mx-1 -my-2.5' : 'mx-1 sm:mx-2 -my-5'
              }`}
              onMouseDown={(e) => e.stopPropagation()}
            >
              {/* Blazing Fiery Flame Halo Burning Around New Score for 7 Seconds */}
              {justScoredGoal && (
                <div
                  aria-hidden="true"
                  className={`absolute rounded-full pointer-events-none goal-flame-ring ${
                    isCompact50 ? '-inset-1.5 sm:-inset-2' : '-inset-3.5 sm:-inset-4'
                  }`}
                  style={{
                    background:
                      'conic-gradient(from 0deg, rgba(239,68,68,0.95), rgba(249,115,22,0.98), rgba(253,224,71,1), rgba(234,88,12,0.95), rgba(220,38,38,0.95), rgba(250,204,21,1), rgba(239,68,68,0.95))',
                    filter: 'blur(6px)',
                  }}
                />
              )}

              {/* Modern Shaking Goal Icon (يتزلزل حول نفسه بلهب ناري مدة 7 ثوانٍ ثم يعود لحالته الطبيعية) */}
              {justScoredGoal && (
                <div
                  className={`absolute z-40 rounded-full bg-gradient-to-r from-red-600 via-orange-500 to-yellow-400 text-white font-black shadow-[0_0_22px_rgba(249,115,22,1),0_0_12px_rgba(253,224,71,0.95)] border border-yellow-200 flex items-center gap-1 goal-icon-quake whitespace-nowrap ${
                    isCompact50
                      ? '-top-4 px-1.5 py-0.5 text-[8px]'
                      : '-top-7 px-2.5 py-1 text-[10px] sm:text-[11px] border-2'
                  }`}
                >
                  <Flame className={`${isCompact50 ? 'w-2.5 h-2.5' : 'w-3.5 h-3.5'} text-yellow-100 fill-yellow-300 shrink-0`} />
                  <span className="drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)]">GOAL!</span>
                  {!isCompact50 && <Sparkles className="w-3 h-3 text-yellow-100 shrink-0" />}
                </div>
              )}

              {/* Outer Brushed Chrome Ring */}
              <div
                data-flash-icon="true"
                className={`relative shadow-[0_8px_24px_rgba(0,0,0,0.92),inset_0_1px_3px_rgba(255,255,255,0.95)] transition-all ${
                  isCompact50 ? 'p-[2px] sm:p-[2.5px]' : 'p-[4px] sm:p-[5px]'
                } ${
                  showInteractive1X2
                    ? 'rounded-[28px] sm:rounded-[34px] bg-[linear-gradient(155deg,#ffffff_0%,#cbd5e1_35%,#475569_70%,#e2e8f0_100%)]'
                    : mode === 'slip'
                    ? 'rounded-[46px] bg-[linear-gradient(155deg,#ffffff_0%,#cbd5e1_35%,#475569_70%,#e2e8f0_100%)]'
                    : 'rounded-full bg-[linear-gradient(155deg,#ffffff_0%,#cbd5e1_35%,#475569_70%,#e2e8f0_100%)]'
                } ${
                  justScoredGoal
                    ? 'goal-quake-7s ring-4 ring-orange-400 shadow-[0_0_32px_rgba(249,115,22,1),0_0_18px_rgba(253,224,71,0.95)]'
                    : isLive
                    ? 'ring-2 ring-emerald-400/80 shadow-[0_0_20px_rgba(16,185,129,0.75)]'
                    : ''
                }`}
              >
                {/* Inner Dark Radial Dial Screen */}
                {showInteractive1X2 ? (
                  <div className="rounded-[24px] sm:rounded-[30px] bg-[radial-gradient(circle_at_50%_25%,#3a414c_0%,#171a20_65%,#080a0d_100%)] border border-slate-400/60 px-1.5 min-[370px]:px-2.5 sm:px-3.5 py-1.5 sm:py-2 flex flex-col items-center justify-center gap-1 shadow-[inset_0_4px_12px_rgba(0,0,0,0.9)]">
                    {/* Center Match Clock Directly Between the Two Teams (ساعة +1 فقط) */}
                    <div
                      dir="ltr"
                      title={`توقيت المباراة: ${plusOneTimeLabel}`}
                      className="flex items-center justify-center gap-1 px-2 py-[2px] rounded-full bg-black/75 border border-amber-400/65 shadow-[0_0_8px_rgba(251,191,36,0.3)] font-mono text-[9.5px] min-[370px]:text-[10.5px] sm:text-[11px] font-black leading-none tabular-nums whitespace-nowrap"
                    >
                      <Clock className="w-2.5 h-2.5 text-yellow-300 shrink-0" />
                      <span className="text-amber-200">{plusOneTimeLabel}</span>
                    </div>

                    <div className="flex items-center gap-1 min-[370px]:gap-1.5">
                      {(['1', 'X', '2'] as const).map((sign) => {
                        const isSelected = activeChoices.includes(sign);
                        return (
                          <button
                            key={sign}
                            type="button"
                            onClick={() => onToggleSelection && onToggleSelection(match.id, sign)}
                            title={`توقع ${sign}`}
                            className={`w-7 h-7 min-[370px]:w-8 min-[370px]:h-8 sm:w-9 sm:h-9 rounded-full font-black text-xs min-[370px]:text-sm sm:text-base transition-all active:scale-90 flex items-center justify-center cursor-pointer select-none ${
                              isSelected
                                ? 'bg-gradient-to-b from-yellow-300 via-amber-400 to-yellow-500 text-black shadow-[0_0_16px_rgba(250,204,21,1)] scale-105 border-2 border-white'
                                : 'bg-black/75 text-gray-100 hover:text-white border border-slate-500 hover:border-yellow-400 hover:bg-slate-800'
                            }`}
                          >
                            {sign}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ) : mode === 'slip' ? (
                  <div className="rounded-[40px] bg-[radial-gradient(circle_at_50%_25%,#3a414c_0%,#171a20_65%,#080a0d_100%)] border border-slate-400/60 px-3 min-[370px]:px-4 sm:px-5 py-1.5 sm:py-2 flex flex-col items-center justify-center gap-0.5 sm:gap-1 min-w-[98px] min-[370px]:min-w-[114px] sm:min-w-[136px] shadow-[inset_0_4px_12px_rgba(0,0,0,0.9)]">
                    <div
                      dir="ltr"
                      className="flex items-center gap-1 font-mono text-[8.5px] sm:text-[9.5px] font-black text-amber-200 tabular-nums whitespace-nowrap"
                    >
                      <Clock className="w-2.5 h-2.5 text-yellow-300 shrink-0" />
                      <span>{plusOneTimeLabel}</span>
                    </div>
                    <ChronometerScore
                      value={displayScoreDash}
                      size="md"
                      isGoalFlash={justScoredGoal}
                      isLive={isLive}
                    />
                    {isLive && (
                      <span className="px-1.5 py-0.5 rounded-full bg-emerald-500/25 border border-emerald-400 text-[9px] font-black text-emerald-300 animate-pulse leading-tight">
                        {match.liveMinute || "1'"}
                      </span>
                    )}

                    {/* Saved Predictions directly inside the circular-pill dial */}
                    <div className="flex items-center gap-1 mt-0.5">
                      {isEditingSlip ? (
                        (['1', 'X', '2'] as const).map((sign) => {
                          const isSelected = activeChoices.includes(sign);
                          return (
                            <button
                              key={sign}
                              type="button"
                              onClick={() => onToggleSelection && onToggleSelection(match.id, sign)}
                              className={`w-6 h-6 rounded-full font-black text-[11px] transition-all flex items-center justify-center cursor-pointer ${
                                isSelected
                                  ? 'bg-gradient-to-b from-yellow-300 to-amber-500 text-black border border-white shadow-[0_0_10px_rgba(250,204,21,0.9)]'
                                  : 'bg-black/80 text-gray-300 border border-slate-600'
                              }`}
                            >
                              {sign}
                            </button>
                          );
                        })
                      ) : activeChoices.length > 0 ? (
                        activeChoices.map((sign) => (
                          <span
                            key={sign}
                            className="w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-gradient-to-b from-yellow-300 to-amber-500 text-black font-black text-[11px] flex items-center justify-center shadow-[0_0_8px_rgba(241,184,22,0.9)] border border-white"
                          >
                            {sign}
                          </span>
                        ))
                      ) : (
                        <span className="text-[10px] text-gray-400 font-bold">--</span>
                      )}
                    </div>
                  </div>
                ) : (
                  /* Exact Iconic Circular Scoreboard Medallion (50% scaled in live tab) */
                  <div
                    className={`rounded-full bg-[radial-gradient(circle_at_50%_25%,#3d4450_0%,#191d24_62%,#080a0d_100%)] border border-slate-400/70 flex flex-col items-center justify-center shadow-[inset_0_4px_14px_rgba(0,0,0,0.92)] ${
                      isCompact50
                        ? 'w-[44px] h-[44px] min-[370px]:w-[48px] min-[370px]:h-[48px] sm:w-[54px] sm:h-[54px]'
                        : 'w-[84px] h-[84px] min-[370px]:w-[96px] min-[370px]:h-[96px] sm:w-[110px] sm:h-[110px]'
                    }`}
                  >
                    <ChronometerScore
                      value={showScoreDisplay ? displayScoreDash : '- - -'}
                      size={isCompact50 ? 'xs' : 'lg'}
                      isGoalFlash={justScoredGoal}
                      isLive={isLive}
                    />
                    {isLive && (
                      <span
                        className={`rounded-full bg-emerald-500/25 border border-emerald-400 font-black text-emerald-300 animate-pulse leading-none ${
                          isCompact50 ? 'mt-0.5 px-1 py-[1px] text-[7px]' : 'mt-1 px-1.5 py-0.2 text-[9px]'
                        }`}
                      >
                        {match.liveMinute || "1'"}
                      </span>
                    )}
                    {!isLive && isFinished && (
                      <span
                        className={`rounded-full bg-yellow-400/20 border border-yellow-300/70 font-black text-yellow-200 leading-none ${
                          isCompact50 ? 'mt-0.5 px-1 py-[1px] text-[7px]' : 'mt-1 px-1.5 py-0.2 text-[9px]'
                        }`}
                      >
                        FT
                      </span>
                    )}
                    {!isLive && !isFinished && !isCompact50 && (
                      <span
                        dir="ltr"
                        className="mt-0.5 px-1.5 py-[1px] rounded-full bg-black/70 border border-amber-400/50 font-mono font-black text-[8px] sm:text-[9px] text-amber-200 leading-none tabular-nums whitespace-nowrap"
                      >
                        {plusOneTimeLabel}
                      </span>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* RIGHT WING: VISITOR TEAM (الفريق الضيف دائماً على اليمين) */}
            <div
              className={`relative z-10 flex items-center flex-1 min-w-0 justify-end ${
                isCompact50
                  ? 'gap-1 sm:gap-1.5 pr-1.5 sm:pr-2.5 pl-0.5'
                  : 'gap-1.5 min-[370px]:gap-2 sm:gap-3 pr-2.5 min-[370px]:pr-3 sm:pr-5 pl-0.5 sm:pl-1'
              }`}
            >
              <div className="min-w-0 text-right">
                <div
                  className={`font-black text-white uppercase tracking-wide drop-shadow-[0_2px_5px_rgba(0,0,0,0.95)] leading-tight ${
                    isCompact50
                      ? 'text-[10px] min-[370px]:text-[11px] sm:text-xs line-clamp-1'
                      : 'text-[12px] min-[370px]:text-[13.5px] sm:text-lg md:text-xl line-clamp-2'
                  }`}
                >
                  {visitorName}
                </div>
                {!isCompact50 && (
                  <span className="text-[9.5px] min-[370px]:text-[10px] sm:text-[11px] font-extrabold text-sky-100/95 block drop-shadow-sm">
                    {lang === 'AR' ? 'ضيف (2)' : 'Visiteur (2)'}
                  </span>
                )}
              </div>
              <div
                data-flash-icon="true"
                className={`shrink-0 rounded-full bg-[#030c22] shadow-[0_2px_4px_rgba(0,0,0,0.65)] flex items-center justify-center overflow-hidden ${
                  isCompact50
                    ? 'w-5 h-5 min-[370px]:w-6 min-[370px]:h-6 sm:w-7 sm:h-7 border border-white p-0.5'
                    : 'w-10 h-10 min-[370px]:w-11 min-[370px]:h-11 sm:w-12 sm:h-12 border-2 border-white p-1'
                }`}
              >
                {renderTeamEmblem(
                  match.awayCrestUrl,
                  awayImgFailed,
                  () => setAwayImgFailed(true),
                  match.awayTeam,
                  match.awayLogo
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 3. ATTACHED LOWER GOLDEN GLOSSY TRANSLUCENT GLASS TRAY (الشريط الأسفل تحت نتيجة كل مباراة: مذهب زجاجي لماع) */}
      <div
        className={`relative z-10 bg-gradient-to-b from-yellow-300/32 via-amber-400/22 to-yellow-500/34 md:backdrop-blur-md shadow-[0_10px_28px_rgba(250,204,21,0.38),inset_0_2px_8px_rgba(254,249,195,0.65),0_4px_0_rgba(120,53,15,0.92)] overflow-hidden ${
          isCompact50
            ? 'mx-1.5 sm:mx-2.5 -mt-[6px] pt-2 pb-1 px-2 sm:px-3 rounded-b-[11px] border-x border-b-[2px] border-yellow-200/85'
            : 'mx-2 sm:mx-6 -mt-[12px] pt-4 pb-2 px-2.5 min-[370px]:px-3.5 sm:px-6 rounded-b-[20px] border-x-2 border-b-[4px] border-yellow-200/85'
        }`}
      >
        {/* Specular glossy glass gleam across the golden translucent tray */}
        <div className="absolute inset-0 bg-gradient-to-br from-white/35 via-transparent to-amber-300/20 pointer-events-none" />
        <div className="absolute top-0 inset-x-0 h-[1px] bg-yellow-100/80 pointer-events-none" />

        <div className={`relative z-10 flex flex-wrap items-center justify-between ${isCompact50 ? 'gap-1 text-[10px]' : 'sm:flex-nowrap gap-2 text-xs'}`}>
          {/* LEFT STACK (Matching Left Column Metadata): Match Number + Date/Time + Column Type / Halftime */}
          <div className="flex flex-col items-start gap-0.5">
            <div className={`flex items-center ${isCompact50 ? 'gap-1' : 'gap-1.5 min-[370px]:gap-2'}`}>
              <div
                data-flash-icon="true"
                className={`rounded-full bg-gradient-to-br from-yellow-200 via-amber-400 to-yellow-600 text-black font-black flex items-center justify-center shadow-[0_0_14px_rgba(254,240,138,0.98)] shrink-0 tabular-nums ${
                  isCompact50
                    ? 'w-4 h-4 text-[9px] border border-white'
                    : 'w-[25px] h-[25px] min-[370px]:w-[27px] min-[370px]:h-[27px] sm:w-[29px] sm:h-[29px] text-[12.5px] min-[370px]:text-[13.5px] sm:text-[14.5px] border-2 border-white'
                }`}
                title={`المباراة رقم ${match.id}`}
              >
                {match.id}
              </div>

              <div
                data-flash-icon="true"
                className={`flex flex-wrap items-center font-black text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.98)] ${
                  isCompact50
                    ? 'gap-1 text-[9.5px] sm:text-[10.5px]'
                    : 'gap-1 min-[370px]:gap-1.5 sm:gap-2 text-[12.5px] min-[370px]:text-[14.5px] sm:text-[16px]'
                }`}
              >
                <Clock className={`${isCompact50 ? 'w-3 h-3' : 'w-[15px] h-[15px] min-[370px]:w-[18px] min-[370px]:h-[18px] sm:w-5 sm:h-5'} text-yellow-100 shrink-0`} />
                <span className="font-mono text-yellow-50 tracking-tight tabular-nums" dir="ltr">
                  {plusOneTimeLabel}
                </span>
                {(!isCompact50 || isFinished) && plusOneDateLabel && (
                  <>
                    <span className="text-yellow-200">•</span>
                    <span
                      className={`font-mono text-amber-100 tracking-tight tabular-nums ${
                        isCompact50
                          ? 'text-[9px] sm:text-[10px]'
                          : 'text-[12px] min-[370px]:text-[13.5px] sm:text-[14.5px]'
                      }`}
                    >
                      {plusOneDateLabel}
                    </span>
                  </>
                )}
                {isCompact50 && match.halftimeScore && (
                  <span className="px-1 py-0 rounded bg-black/55 border border-cyan-300/60 text-cyan-100 font-mono text-[8.5px] tabular-nums" dir="ltr">
                    HT {match.halftimeScore}
                  </span>
                )}
              </div>
            </div>

            {!isBettingLocked && (mode === 'fill' || mode === 'slip') && (
              <div className="flex items-center gap-1 text-[10px] font-black text-yellow-50/95 pl-8 drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)]">
                <Layers className="w-3 h-3 text-yellow-200" />
                <span>{matchColumnLabel}</span>
              </div>
            )}
          </div>

          {/* RIGHT STACK (Matching Right Column Metadata): Live Indicator / Official Result / Probabilities / Favorite & Live Watch */}
          <div className="flex flex-col items-end gap-1 text-right">
            {mode === 'live' ? (
              <div className="flex flex-wrap items-center justify-end gap-1" dir="rtl">
                {isLive ? (
                  <span className="flex items-center gap-1 px-1.5 py-0.5 rounded-full bg-emerald-600/90 border border-emerald-200 text-white font-black text-[9px] shadow-[0_0_10px_rgba(16,185,129,0.9)] whitespace-nowrap">
                    <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping shrink-0" />
                    <span className="tabular-nums">{match.liveMinute || "1'"}</span>
                  </span>
                ) : isFinished ? (
                  <span className="flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-black/70 border border-yellow-200/85 text-yellow-100 font-black text-[9px] shadow whitespace-nowrap">
                    <Trophy className="w-2.5 h-2.5 text-yellow-300 shrink-0" />
                    <span>انتهت</span>
                  </span>
                ) : (
                  <span className="px-1.5 py-0.5 rounded-full bg-black/55 border border-yellow-200/60 text-yellow-50 font-bold text-[9px] whitespace-nowrap">
                    قيد الانتظار
                  </span>
                )}

                {!isFinished && onToggleWatchLive && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleWatchLive();
                    }}
                    title="تفعيل أو إيقاف المشاهدة المباشرة لهذه المباراة"
                    className={`min-h-[26px] px-2 py-0.5 rounded-lg border font-black text-[9.5px] flex items-center gap-1 transition-all cursor-pointer active:scale-95 whitespace-nowrap shrink-0 ${
                      isWatchingLive
                        ? 'bg-emerald-500 text-black border-white shadow-[0_0_10px_rgba(16,185,129,0.9)]'
                        : 'bg-black/65 hover:bg-emerald-950/90 text-emerald-200 border-emerald-400/70'
                    }`}
                  >
                    <Tv className="w-3 h-3 shrink-0" />
                    <span>{isWatchingLive ? 'فعالة' : 'مشاهدة'}</span>
                  </button>
                )}

                {onToggleFavorite && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleFavorite();
                    }}
                    title={isFavorite ? 'إزالة من التفضيلات' : 'إضافة إلى التفضيلات'}
                    className={`min-h-[26px] min-w-[26px] px-1.5 py-0.5 rounded-lg border font-black text-[9.5px] flex items-center justify-center gap-0.5 transition-all cursor-pointer active:scale-95 whitespace-nowrap shrink-0 ${
                      isFavorite
                        ? 'bg-gradient-to-b from-yellow-300 to-amber-500 text-black border-white shadow-[0_0_10px_rgba(250,204,21,0.95)]'
                        : 'bg-black/65 hover:bg-amber-950/85 text-yellow-200 border-yellow-300/70'
                    }`}
                  >
                    <Star className={`w-3 h-3 shrink-0 ${isFavorite ? 'fill-black text-black' : ''}`} />
                    <span>{isFavorite ? 'مفضلة' : 'تفضيل'}</span>
                  </button>
                )}
              </div>
            ) : mode === 'tirage' || mode === 'home' ? (
              <div className="flex items-center gap-2">
                {isDelayed ? (
                  <span className="px-2.5 py-0.5 rounded-full bg-amber-950/80 border border-amber-300/75 text-amber-200 font-black text-[11px]">
                    مؤجلة / قيد التحديث
                  </span>
                ) : isLive ? (
                  <span className="flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-emerald-600/80 border border-emerald-200 text-white font-black text-[11px] shadow-[0_0_12px_rgba(16,185,129,0.9)] animate-pulse">
                    <span className="w-2 h-2 rounded-full bg-white animate-ping" />
                    <span>مباشر {match.liveMinute || "1'"}</span>
                  </span>
                ) : hasResult ? (
                  <div className="flex items-center gap-1.5 font-black text-[11px] sm:text-xs text-white drop-shadow-[0_1px_3px_rgba(0,0,0,0.95)]">
                    <span>النتيجة المعتمدة:</span>
                    <span className="px-2.5 py-0.5 rounded-lg bg-black/75 border border-yellow-200 text-yellow-200 font-mono shadow-md">
                      {match.result}
                    </span>
                  </div>
                ) : (
                  <span className="px-2.5 py-0.5 rounded-full bg-black/55 border border-yellow-200/60 text-yellow-50 font-bold text-[11px]">
                    قيد الانتظار
                  </span>
                )}
              </div>
            ) : isBettingLocked || mode === 'slip' ? (
              <div className="flex items-center gap-1.5">
                {isDelayed ? (
                  <span className="px-2.5 py-0.5 rounded-full bg-amber-950/80 border border-amber-300/75 text-amber-200 font-black text-[11px]">
                    مؤجلة / قيد التحديث
                  </span>
                ) : isLive ? (
                  <span className="flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-emerald-600/85 border border-emerald-200 text-white font-black text-[11px] shadow-[0_0_14px_rgba(16,185,129,0.95)] animate-pulse">
                    <span className="w-2 h-2 rounded-full bg-white animate-ping" />
                    <span>مباشر {match.liveMinute || "1'"}</span>
                  </span>
                ) : isFinished && hasResult ? (
                  <div className="flex items-center gap-1.5">
                    <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-black/70 border border-yellow-200/90 text-yellow-100 font-black text-[11px] shadow">
                      <Trophy className="w-3 h-3 text-yellow-300" />
                      <span>النتيجة: {match.result}</span>
                    </div>
                    {mode === 'slip' && (
                      isCorrect ? (
                        <span className="flex items-center gap-0.5 px-2 py-0.5 rounded-full bg-emerald-600/90 text-white border border-emerald-200 font-black text-[10px]">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>صح</span>
                        </span>
                      ) : (
                        <span className="flex items-center gap-0.5 px-2 py-0.5 rounded-full bg-red-600/90 text-white border border-red-200 font-black text-[10px]">
                          <XCircle className="w-3 h-3" />
                          <span>خطأ</span>
                        </span>
                      )
                    )}
                  </div>
                ) : isFinished ? (
                  <span className="px-2.5 py-0.5 rounded-full bg-black/65 border border-yellow-200/80 text-yellow-100 font-black text-[11px]">
                    انتهت المقابلة
                  </span>
                ) : (
                  <span className="flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-black/55 border border-yellow-200/60 text-yellow-50 font-bold text-[11px]">
                    <Clock className="w-3 h-3 text-yellow-200" />
                    <span>في انتظار البداية</span>
                  </span>
                )}
              </div>
            ) : (
              /* Unlocked Grille: Display Crisp Odds / Probabilities on Golden Glass */
              <div
                data-flash-icon="true"
                className="flex items-center gap-1.5 font-mono text-[11px] sm:text-xs font-black bg-black/50 px-2.5 py-1 rounded-lg border border-yellow-200/70 text-white shadow-sm"
              >
                <span className="text-emerald-300">1:{match.prob1}%</span>
                <span className="text-yellow-200/60">|</span>
                <span className="text-yellow-200">X:{match.probX}%</span>
                <span className="text-yellow-200/60">|</span>
                <span className="text-cyan-200">2:{match.prob2}%</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
